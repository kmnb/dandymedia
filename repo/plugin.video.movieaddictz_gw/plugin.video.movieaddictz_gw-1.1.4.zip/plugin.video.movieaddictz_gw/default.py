# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,cloudflare,net
import urlresolver
import requests
import xbmcaddon
from addon.common.addon import Addon
net = net.Net()
addon_id='plugin.video.movieaddictz_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.movieaddictz_gw/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'movieaddictz_gw'
VERSION = '1.1.4'
BASEURL = 'http://vumoo.li'
ART = ADDON_PATH + "resources/icons/"
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

def Main_menu():
    addDir('[B][COLOR red]Popular This Week[/COLOR][/B]',BASEURL + '/videos/category/popular-this-week',5,ART + 'popular.jpg',FANART,'')
    addDir('[B][COLOR red]Currently Watching[/COLOR][/B]',BASEURL + '/videos/category/currently-watching',5,ART + 'current.jpg',FANART,'')
    addDir('[B][COLOR red]Recently Added[/COLOR][/B]',BASEURL + '/videos/category/recently-added',5,ART + 'recent.jpg',FANART,'')
    addDir('[B][COLOR red]New Releases[/COLOR][/B]',BASEURL + '/videos/category/new-releases',5,ART + 'new_rel.jpg',FANART,'')
    addDir('[B][COLOR red]IMDB Top Rated[/COLOR][/B]',BASEURL + '/videos/category/top-rated-imdb',5,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR red]Movie by Genre[/COLOR][/B]','',8,ART + 'genre.jpg',FANART,'')
    addDir('[B][COLOR red]Search for a Movie[/COLOR][/B]','url',6,ART + 'search_mov.jpg',FANART,'')
    addDir('[B][COLOR blue]Trending TV[/COLOR][/B]',BASEURL + '/videos/category/trending-television',2,ART + 'trendingtv.jpg',FANART,'')
    addDir('[B][COLOR blue]Search for a TV Show[/COLOR][/B]','url',7,ART + 'TV_search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="slick-slide.+?<a href="(.+?)".+?data-title="(.+?)".+?style="background-image: url\((.+?)\);',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        if 'Da Vinci' not in name:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,20,icon,FANART,'')
    np = re.compile('<div class="navigation"> <a href="(.+?)">',re.DOTALL).findall(OPEN)
    for url in np:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL + '/%s'%url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('<ul class="multi-column-dropdown">(.+?)</ul> </div> </div> </ul> </div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR red]%s[/COLOR][/B]' %name,BASEURL + '/%s'%url,5,ART + 'genre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="slick-slide.+?<a href="(.+?)".+?data-title="(.+?)".+?style="background-image: url\((.+?)\);',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex: 
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + '/%s'%url,3,icon,FANART,'')
    np = re.compile('<div class="navigation"> <a href="(.+?)">',re.DOTALL).findall(OPEN)
    for url in np:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL + '/%s'%url,2,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episode(url):
    OPEN = Open_Url(url)
    Regex = re.compile(' <li id=season.+?<h2>(.+?)</h2> <span class="season-info">(.+?)</span>.+?<span class="season-info air-date">(.+?)</span>.+?data-click="/api/plink(.+?)"',re.DOTALL).findall(OPEN)
    for info,epis,airdate,url in Regex:
            airdate=airdate.replace('Air date: ','')
            name = epis + ' - ' + info + ' - [COLOR red]' + airdate
            url = '/api/plink' + url
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + '%s'%url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def end_links(url):
    OPEN = Open_Url(url)
    Regex = re.compile("var p_link_id='(.+?)'.+?\+p_link_id\+\"(.+?)\"",re.DOTALL).findall(OPEN)
    for var,imdb in Regex:
        page = 'http://vumoo.li/api/getContents?id=' + var + imdb   #correct to here
        links = Open_Url(page)
        regex2 = re.compile('"src":"(.+?)","label":"(.+?)"',re.DOTALL).findall(links)
        for url,name2 in regex2:
            url=url.replace('\/','/')
            addDir('[B][COLOR white]Play in %s[/COLOR][/B]'%name2,'http://vumoo.li%s'%url,100,iconimage,FANART,name)
    OLOAD = re.compile("var openloadLink = '(.+?)'",re.DOTALL).findall(OPEN)
    for url in OLOAD:
        addDir('[B][COLOR blue]Openload[/COLOR][/B]',url,100,iconimage,FANART,name)
      
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Search():
        keyb = xbmc.Keyboard('', 'Search for a Movie')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + "/videos/search/?search=" + search
                Get_content(url)

def Search_TV():
        keyb = xbmc.Keyboard('', 'Search for a TV Show')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + "/videos/search/?search=" + search
                Get_TV(url)
########################################

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

#removed urlresolver unless need readd openload links 
def resolve(name,url,iconimage,description):
    if '/api/plink' in url:    
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
    else:
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
      
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 2 : Get_TV(url)
elif mode == 3 : Get_episode(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Search_TV()
elif mode == 8 : Get_genres()
elif mode == 20 : end_links(url)
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
