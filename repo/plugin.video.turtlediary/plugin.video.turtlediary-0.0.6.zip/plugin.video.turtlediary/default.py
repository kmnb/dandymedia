# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy, xbmcaddon
from addon.common.addon import Addon
addon_id='plugin.video.turtlediary'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'turtlediary'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'https://www.turtlediary.com'


def Main_Menu():
    addDir('[B][COLOR lime]All Grades[/COLOR][/B]','https://www.turtlediary.com/videos.html?sort=alpha',2,ICON,FANART,'')
    OPEN = Open_Url('https://www.turtlediary.com/videos.html?sort=alpha')
    Regex = re.compile('</i>Videos <(.+?)<ul class="tools-mm toolsSec"> ',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR lime]%s[/COLOR][/B]' %name,url,2,ICON,FANART,'')
    setView('tvshows', 'tvshows-view')
	
def Pre_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="head-right">(.+?)<div class="head-top',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)".+?<img src="(.+?)"/>.+?<span class="LangName">(.+?)</span>',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
            if 'Science' in name:
			icon=ART + 'science.jpg'
            if 'Math' in name:
			icon=ART + 'math.jpg'
            if 'Language' in name:
			icon=ART + 'lang.jpg'
            addDir('[B][COLOR lime]%s[/COLOR][/B]' %name,BASEURL+url,1,icon,FANART,'')
    setView('tvshows', 'tvshows-view')	

def Second_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="echThmb_in">.+?<a href="(.+?)".+?<img itemprop="image" src="(.+?)" title="(.+?)".+?>',re.DOTALL).findall(OPEN)
    for url,img,name in Regex:
            url = BASEURL + url
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,img,FANART,'')
    np = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '&raquo;' in name:
                    addDir('Next Page>>>',url,1,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
    

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100 or mode==101:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
		
def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
        
def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    url = re.compile('<meta itemprop="contentURL" content="(.+?)"/>',re.DOTALL).findall(OPEN)[0]
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_Menu()
elif mode == 1 : Second_Menu(url)
elif mode == 2 : Pre_Menu(url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
