# -*- coding: utf-8 -*-
import json, os, re, requests, sys, urllib2, urllib, urlresolver, xbmc, xbmcaddon, xbmcgui, xbmcplugin

s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')

SHID        = ID.replace('plugin.video.','')
ART         = ADDON_PATH + "/resources/icons/"
BASEURL     = 'http://www.watchepisodeseries.com/'

def Main_menu():
    addDir('[B][COLOR white]Latest Episodes[/COLOR][/B]',BASEURL,7,ART + 'latest.jpg',FANART,'')
    addDir('[B][COLOR white]New Series[/COLOR][/B]',BASEURL + 'home/new-series',5,ART + 'new.jpg',FANART,'')
    addDir('[B][COLOR white]Popular Series[/COLOR][/B]',BASEURL + 'home/popular-series',5,ART + 'popularseries.jpg',FANART,'')
    addDir('[B][COLOR white]Trending Series[/COLOR][/B]',BASEURL + 'home/series',4,ART + 'trending.jpg',FANART,'')
    addDir('[B][COLOR white]Browse All Series[/COLOR][/B]',BASEURL + 'home/series',6,ART + 'browse.jpg',FANART,'')
    addDir('[B][COLOR white]Browse Series by Genres[/COLOR][/B]',BASEURL + 'home/series',3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR white]Search for a Series[/COLOR][/B]','url',20,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="genres">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<input data-genrename="(.+?)".+?<div class="cl-text">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2: 
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'home/series?genres=%s'%url,6,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="cover-box">.+?<div title="(.+?)".+?style="background-image: url\(\'(.+?)\'\)">.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for name,icon,url in Regex:
        name=name.replace('&#39;','\'').replace('amp;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Browse_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="wide-serie-box half">.+?style="background-image: url\(\'(.+?)\'\)"></a>.+?<div class="wsbr-title"><h3><a href="(.+?)">(.+?)</a></h3></div>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name=name.replace('&#39;','\'').replace('amp;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    np = re.compile('<ul class="pagination">(.+?)</ul>',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(np))
    for url,name in np2:
        if 'Next' in name:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,6,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_trending(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="trending-box">.+?style="background-image: url\(\'(.+?)\'\)">.+?<a href="(.+?)" class="tb-title">Watch (.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name=name.replace('&#39;','\'').replace('amp;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_lat_ep(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="featured-ep-.+?title="(.+?)">.+?style="background-image: url\(\'(.+?)\'\)">.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for name,icon,url in Regex:
        name=name.replace('&#39;','\'')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="el-item">.+?<a href="(.+?)">.+?<div class="season">(.+?)</div>.+?<div class="episode">(.+?)</div>.+?<div class="name">(.+?)</div>.+?<div class="date">(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,sea,epis,title,date in Regex:
        if 'Season 0' not in sea:
            date=date.replace(' ','').replace('\n','')
            title=title.replace('&#39;','\'').replace('amp;','')
            name = '[B][COLOR red]%s' %sea+' - ' + epis + '[COLOR white] - ' + title + ' - ' + '[COLOR red]('+date+')[/COLOR][/B]'
            addDir(name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    referer = url
    headers = {'Host': 'www.watchepisodeseries.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="ll-item">.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if 'lolzor.com' in name2:
            name2 = name2.replace('lolzor.com','[COLOR red]GoogleLinks')
            addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,150,iconimage,FANART,name)
        if 'mycollection.net' in name2:
            name2 = name2.replace('mycollection.net','[COLOR red]GoogleLinks')
            addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,12,iconimage,FANART,name)
        if 'likeafool.com' in name2:
            name2 = name2.replace('likeafool.com','[COLOR red]GoogleLinks[/COLOR]')
            addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,12,iconimage,FANART,name)
        if 'vidbaba.com' in name2:
            name2 = name2.replace('vidbaba.com','[COLOR red]GoogleLinks[/COLOR]')
            addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,12,iconimage,FANART,name)
    for url,name2 in Regex:
        if 'lolzor.com' not in name2:
            if 'likeafool.com' not in name2:
                if 'vidbaba.com' not in name2:
                    if 'gagomatic.com' not in name2:
                        if 'funblr.com' not in name2:
                            if 'favour.me' not in name2:
                                if 'allmyvideos.net' not in name2:
                                    if 'adhqmedia.com' not in name2:
                                        if 'filehoot.com' not in name2:
                                            if 'mycollection.net' not in name2:
                                                if 'vidaaazi.tv' not in name2:
                                                    if 'vidzi.tv' not in name2: ###check later date
                                                        addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,150,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def get_google(name,url):
    name = description
    OPEN = Open_Url(url)
    Regex = re.compile('<a rel="nofollow" target="_blank" href="(.+?)"',re.DOTALL).findall(OPEN)
    for get_urls in Regex:
        get_urls = get_urls.replace('http://www.likeafool.com/files/','http://embed.likeafool.com/files/embed/').replace('http://www.vidbaba.com/new_files/','http://www.mycollection.net/new_files/embed/').replace('http://www.mycollection.net/bishop/','http://www.mycollection.net/bishop/embed/')
        end_links = Open_Url(get_urls)
        vids = re.compile('file: "(.+?)".+?label: "(.+?)"',re.DOTALL).findall(end_links)
    for url,name2 in vids:
        addDir('[B][COLOR white]GoogleLink [COLOR red]in %s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search(query):
    if query and query != None and query != "": search = query.replace(' ','+')
    else:
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()): search = keyb.getText().replace(' ','+').replace('+and+','+%26+')
    if len(search) > 0:
        url = '%shome/search?q=%s' % (BASEURL, search)
        Search_Results(url)

def Search_Results(url):
    OPEN = Open_Url(url)
    results = json.loads(OPEN)
    results = results['series']
    for result in results:
        name = result['original_name']
        slug = result['seo_name']
        url = 'http://www.watchepisodeseries.com/%s' % slug
        icon = 'http://www.watchepisodeseries.com/series_images/%s.jpg' % slug
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name,url,8,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==150:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def resolve(name,url,iconimage,description):
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def alt_resolve(name,url,iconimage,description):
    try:
        OPEN = Open_Url(url)
        url = re.compile('<div class="wb-main">.+?<a rel="nofollow" target="_blank" href="(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = url.replace('https://openload.cc','https://openload.co').replace('http://www.lolzor.com/bach/','http://www.lolzor.com/bach/embed/').replace('http://vodlocker.city/','http://vodlocker.com/')
        if 'lolzor' in url:
            link2 = Open_Url(url)
            vid = re.compile('file: "(.+?)"').findall(link2)[-1]
            stream_url=urlresolver.HostedMediaFile(vid).resolve()
        else: stream_url=urlresolver.HostedMediaFile(url).resolve()
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
    return param

params=get_params()
url=BASEURL
name=NAME
iconimage=ICON
mode=None
fanart=FANART
description=DESCRIPTION
query=None


try   : url=urllib.unquote_plus(params["url"])
except: pass
try   : name=urllib.unquote_plus(params["name"])
except: pass
try   : iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try   : mode=int(params["mode"])
except: pass
try   : fanart=urllib.unquote_plus(params["fanart"])
except: pass
try   : description=urllib.unquote_plus(params["description"])
except: pass
try   : query=urllib.unquote_plus(params["query"])
except: pass


print SHID + ': ' + VERSION
print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "IconImage: " + str(iconimage)
#########################################################

if   mode == None : Main_menu()
elif mode == 3    : Get_Genres(url)
elif mode == 4    : Get_trending(url)
elif mode == 5    : Get_content(url)
elif mode == 6    : Browse_content(url)
elif mode == 7    : Get_lat_ep(url)
elif mode == 8    : Episodes(url)
elif mode == 10   : Get_links(name,url)
elif mode == 11   : Search_Results(url)
elif mode == 12   : get_google(name,url)
elif mode == 20   : Search(query)
elif mode == 100  : resolve(name,url,iconimage,description)
elif mode == 150  : alt_resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))