import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,base64
import xbmcaddon
import urlresolver
from addon.common.addon import Addon
from md_request import open_url
from metahandler import metahandlers
### Big thanks to MuckyDuck for the use of this function###
addon_id='plugin.video.jafma'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2'
BASEURL = 'https://www.rjsmovie.co'
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData()

def MENU():
    addDir('[B][COLOR orange]Featured Movies[/COLOR][/B]',BASEURL + '/genre/featured/',5,ART + 'featured.jpg',FANART,'')
    addDir('[B][COLOR orange]Rated Movies[/COLOR][/B]',BASEURL + '/ratings/?get=movies',5,ART + 'rated.jpg',FANART,'')
    addDir('[B][COLOR orange]All Movies[/COLOR][/B]',BASEURL + '/movies/',5,ART + 'allmovies.jpg',FANART,'')
    addDir('[B][COLOR orange]Trending Movies[/COLOR][/B]',BASEURL + '/trending/?get=movies',5,ART + 'trending.jpg',FANART,'')
    addDir('[B][COLOR orange]IMDB Rated[/COLOR][/B]',BASEURL + '/top-imdb/',7,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR orange]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR orange]TV Shows[/COLOR][/B]',BASEURL + '/tvshows/',5,ART + 'tvshows.jpg',FANART,'')
    addDir('[B][COLOR orange]IMDB Rated TV[/COLOR][/B]',BASEURL + '/top-imdb/',8,ART + 'imdbtv.jpg',FANART,'')
    addDir('[B][COLOR red]Search[/COLOR][/B]','url',6,ART + 'search_all.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    OPEN = open_url(url).content
    Regex = re.compile('<div class="poster">.+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)".+?<div class="data">.+?<span>(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,icon,title,year in Regex:
        items = len(Regex)
        title = title.replace(' Full Movie','')
        title = cleanHex(title)
        if '|' in title:
            try:        
                title = title.split('| ')[1]
            except:pass
        if '/ ' in title:        
            title = title.split('/ ')[0]
        if '(' in title:        
            title = title.split('(')[0]
        name  = title + ' (' + year +')'
        if 'tvshows' in url:
            if metaset=='true':
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,items)
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
        else:
            if metaset=='true':
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,items)
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    setView('movies', 'movie-view')

def Get_Genres(url):
    OPEN = open_url(url).content
    Regex = re.compile('>Genres</a>(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('href="(.+?)">(.+?)<',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_imdb(url):
    OPEN = open_url(url).content
    Regex = re.compile('TOP IMDb 30</h1>(.+?)<h3>TV Shows</h3>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="poster".+?img src="(.+?)".+?href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex)) 
    for icon,url,name in Regex2:
        items = len(Regex2)
        if '|' in name:        
            name = name.split('| ')[1]
        icon = icon.replace('w90','w300_and_h450_bestv2').replace('-90x135','')
        name=name.replace('\\xc3','e').replace('\\xa9','').replace('\\xc2','').replace('\\xb7','-')
        if metaset=='true':
            addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,items)
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    setView('movies', 'movie-view')

def tv_imdb(url):
    OPEN = open_url(url).content
    Regex = re.compile('<h3>TV Shows</h3>(.+?)<footer class="main">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="poster".+?img src="(.+?)".+?href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex)) 
    for icon,url,name in Regex2:
        items = len(Regex2)
        if '|' in name:        
            name = name.split('| ')[1]
        icon = icon.replace('w90','w300_and_h450_bestv2').replace('-90x135','')
        name=name.replace('\\xc3','e').replace('\\xa9','').replace('\\xc2','').replace('\\xb7','-')
        if metaset=='true':
            addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,items)
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    setView('movies', 'movie-view')
    
def Get_show_content(url):
    OPEN = open_url(url).content
    Regex = re.compile('class="imagen"><a href="(.+?)".+?class="numerando">(.+?)</div>.+?href=".+?">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name1,name2 in Regex:
            name = name1+'   '+name2
            name = name.replace('&#039;','\'').replace('amp;','')
            addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(url):
    OPEN = open_url(url).content
    reg = re.compile('https://embed.thewatchseries.us/(.+?)"',re.DOTALL).findall(OPEN)[0]
    reg = 'https://embed.thewatchseries.us/' +reg
    holderpage = open_url(reg).content
    Regex = re.compile("src='(.+?)'.+?label='(.+?)'",re.DOTALL).findall(holderpage)
    for url,name2 in Regex:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = open_url(url).content
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            if '|' in name:        
                name = name.split('| ')[1]
            name = name.replace('&#8217;','').replace('#038;','')
            icon = icon.replace('w90','w300_and_h450_bestv2').replace('-150x150','')
            if '/tvshows/' in url:
                addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')    
            else:
                addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)') 



    
def RESOLVE(url):
    links = open_url(url).content
    if 'https://embed.thewatchseries.us/' in links:
        try:
            res_quality = []
            stream_url = []
            quality = ''
            reg = re.compile('https://embed.thewatchseries.us/(.+?)"',re.DOTALL).findall(links)[0]
            reg = 'https://embed.thewatchseries.us/' +reg
            holderpage = open_url(reg).content
            match = re.compile("src='(.+?)'.+?label='(.+?)'",re.DOTALL).findall(holderpage)
            for link, label in match:
                if 'auto' not in label:
                    quality = '[B][COLOR orange]%s[/COLOR][/B]' %label
                    res_quality.append(quality)
                    stream_url.append(link)
            if len(match) >1:
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select('Please Select Quality',res_quality)
                    if ret == -1:
                        return
                    elif ret > -1:
                            url = stream_url[ret]
            else:
                url = re.compile('src="(.+?)"',re.DOTALL).findall(holderpage)[0]
        except:
            url = re.compile('src="https://openload.co/embed/(.+?)"',re.DOTALL).findall(links)[0]
            url = 'https://openload.co/embed/' + url
    else:
        try:
            res_quality = []
            stream_url = []
            quality = ''
            match = re.compile('"file":"(.+?)".+?"label":"(.+?)"').findall(links)
            for link, label in match:
                if 'Auto' not in label:
                    quality = '[B][COLOR orange]%s[/COLOR][/B]' %label
                    res_quality.append(quality)
                    stream_url.append(link)
            if len(match) >1:
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select('Please Select Quality',res_quality)
                    if ret == -1:
                        return
                    elif ret > -1:
                            url = stream_url[ret]
                            url = url.replace('\/','/')
            else:
                url = re.compile('"file":"(.+?)"').findall(links)[0]
                url = url.replace('\/','/')
        except:
            try:
                url = re.compile('<iframe.+?src="(.+?)"').findall(links)[0]
            except:pass
    stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

# def RESOLVE_tv(url):
    # links = open_url(url).content
    # if 'https://www.playerproxy.stream/embed/' in links:
            # res_quality = []
            # stream_url = []
            # quality = ''
            # reg = re.compile('https://www.playerproxy.stream/embed/(.+?)"').findall(links)[0]
            # reg = 'https://www.playerproxy.stream/embed/' +reg
            # holderpage = open_url(reg).content
            # match = re.compile("src: '(.+?)'.+?label: '(.+?)'",re.DOTALL).findall(holderpage)
            # for link, label in match:
                # if 'text-decoration' not in label:
                    # quality = '[B][COLOR orange]%s[/COLOR][/B]' %label
                    # res_quality.append(quality)
                    # stream_url.append(link)
            # if len(match) >1:
                    # dialog = xbmcgui.Dialog()
                    # ret = dialog.select('Please Select Quality',res_quality)
                    # if ret == -1:
                        # return
                    # elif ret > -1:
                            # url = stream_url[ret]
            # else:
                # url = re.compile("src: '(.+?)'.+?label: '(.+?)'",re.DOTALL).findall(match)[0]
    # stream_url = urlresolver.resolve(url)
    # liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    # liz.setInfo(type="Video", infoLabels={"Title": name})
    # liz.setProperty("IsPlayable","true")
    # liz.setPath(stream_url)
    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    

    
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))
                
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==101:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        splitName=name.partition('(')
        simplename=""
        simpleyear=""
        if len(splitName)>0:
            simplename=splitName[0]
            simpleyear=splitName[2].partition(')')
        if len(simpleyear)>0:
            simpleyear=simpleyear[0]
        mg = eval(base64.b64decode('bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ=='))
        meta = mg.get_meta('movie', name=simplename ,year=simpleyear)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=iconimage
        name = '[B][COLOR orange]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 99, 'url':meta['trailer']})))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image',FANART)
        if mode==100 or mode==101:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok

def notification(title, message, icon):
        addon.show_small_popup( addon.get_name(), message.title(), 5000, icon)
        return
    
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

def PT(url):
        addon.log('Play Trailer %s' % url)
        notification( addon.get_name(), 'fetching trailer', addon.get_icon())
        xbmc.executebuiltin("PlayMedia(%s)"%url)
    

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 3 : Get_Genres(url)
elif mode == 5 : Get_content(url) 
elif mode == 6 : Search()
elif mode == 7 : Get_imdb(url)
elif mode == 8 : tv_imdb(url)
elif mode == 9 : Get_show_content(url)
elif mode == 10 : Get_links(url)
elif mode==99: PT(url)
elif mode ==100: RESOLVE(url)
elif mode ==101: RESOLVE_tv(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















