import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,cloudflare,net
import xbmcaddon
import urlresolver
from addon.common.addon import Addon
net = net.Net()
addon_id='plugin.video.jafma'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0'
BASEURL = 'https://seriesonline.io'
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

def MENU():
    addDir('[B][COLOR orange]Latest Movies[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/12-13/all/latest/',5,ART + 'lat_mov.jpg',FANART,'')
    addDir('[B][COLOR orange]Cinema Movies[/COLOR][/B]',BASEURL + '/movie/filter/cinema/all/all/12-13/all/latest/',5,ART + 'cinema.jpg',FANART,'')
    addDir('[B][COLOR orange]Most Viewed[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/12-13/all/most/',5,ART + 'm_view.jpg',FANART,'')
    addDir('[B][COLOR orange]IMDB Rated[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/12-13/all/imdb/',5,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR orange]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR orange]Latest TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/12-13/all/latest/',5,ART + 'l_tv.jpg',FANART,'')
    addDir('[B][COLOR orange]Most Viewed TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/12-13/all/most/',5,ART + 'mvtv.jpg',FANART,'')
    addDir('[B][COLOR orange]IMDB Rated TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/12-13/all/imdb/',5,ART + 'imdbtv.jpg',FANART,'')
    addDir('[B][COLOR white]All Countries Menu[/COLOR][/B]','url',7,ART + 'countries.jpg',FANART,'')
    addDir('[B][COLOR red]Search All[/COLOR][/B]','url',6,ART + 'search_all.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    if '?page' not in url:
        CURRENT=url
    else:
        CURRENT=url.split('?')[0]
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="ml-item".+?href="(.+?)".+?title="(.+?)".+?<span class=.+?>(.+?)</span>.+?<img data-original="//(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,qual,icon in Regex:
        url = url+'/watching.html'
        if 'eason-' in url or 'Eps<i>' in qual:
            addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,BASEURL+url,9,'http://%s'%icon,FANART,name)
        else:
            name = name + '[COLOR red] (' + qual + ')[/COLOR]' 
            addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,BASEURL+url,100,'http://%s'%icon,FANART,'')
    np = re.compile("<div id=\"pagination\">.+?class=active><a href=.+?href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]',CURRENT+url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('title="Genre">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="/genre/(.+?)">(.+?)<',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url='/movie/filter/movie/all/' + url + '12-13/all/latest/'
        addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Get_show_content(url):
    bollox=description
    OPEN = Open_Url(url)
    Regex = re.compile('list-eps(.+?)clearfix',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a title="(.+?)" player-data="(.+?)"',re.DOTALL).findall(str(Regex)) 
    for name,url in Regex2:
        name = name.replace('\\','')
        name = name.replace(bollox,'').replace(': ','').lstrip()
        addDir('[B][COLOR orange]%s[/COLOR][/B]' %name,url,101,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

# def Get_links(url):
    # OPEN = Open_Url(url)
    # holderpage = re.compile('<iframe src="(.+?)"').findall(OPEN)[0]
    # link = Open_Url(holderpage)
    # urls=re.compile('src=\'(.+?)\'.+?label=\'(.+?)\'',re.DOTALL).findall(link)
    # for url,name2 in urls:
        # if 'auto' not in name2:
            # url=url.replace(' ','%20').replace('amp;','')
            # addDir('[B][COLOR chartreuse]%s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    # xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + '/movie/search/' + search
                Get_content(url)


def all_MENU():
    addDir('[B][COLOR white]Latest Movies[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/all/all/latest/',5,ART + 'lat_mov.jpg',FANART,'')
    addDir('[B][COLOR white]Cinema Movies[/COLOR][/B]',BASEURL + '/movie/filter/cinema/all/all/all/all/latest/',5,ART + 'cinema.jpg',FANART,'')
    addDir('[B][COLOR white]Most Viewed[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/all/all/most/',10,ART + 'm_view.jpg',FANART,'')
    addDir('[B][COLOR white]IMDB Rated[/COLOR][/B]',BASEURL + '/movie/filter/movie/all/all/all/all/imdb/',5,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,8,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR white]Latest TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/all/all/latest/',5,ART + 'l_tv.jpg',FANART,'')
    addDir('[B][COLOR white]Most Viewed TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/all/all/most/',5,ART + 'mvtv.jpg',FANART,'')
    addDir('[B][COLOR white]IMDB Rated TV[/COLOR][/B]',BASEURL + '/movie/filter/series/all/all/all/all/imdb/',5,ART + 'imdbtv.jpg',FANART,'')
    addDir('[B][COLOR orange]UK/US Only Menu[/COLOR][/B]','url','',ART + 'ukus.jpg',FANART,'')
    addDir('[B][COLOR red]Search All[/COLOR][/B]','url',6,ART + 'search_all.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def All_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('title="Genre">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="/genre/(.+?)">(.+?)<',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url='/movie/filter/movie/all/' + url + 'all/all/latest/'
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def RESOLVE(url):
    res_quality = []
    stream_url = []
    quality = ''
    OPEN = Open_Url(url)
    holderpage = re.compile('<iframe src="(.+?)"').findall(OPEN)[0]
    links = Open_Url(holderpage)
    match = re.compile("file: '(.+?)'.+?label: '(.+?)'").findall(links)
    for link, label in match:
        if 'Auto' not in label:
            quality = '[B][COLOR orange]%s[/COLOR][/B]' %label
            res_quality.append(quality)
            stream_url.append(link)
    if len(match) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Quality',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                    url = stream_url[ret]
    else:
        url = re.compile("file: '(.+?)'").findall(links)[0]
    url=url.replace(' ','%20').replace('amp;','')
    stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def RESOLVE_tv(url):
    res_quality = []
    stream_url = []
    quality = ''
    OPEN = Open_Url(url)
    match = re.compile("file: '(.+?)'.+?label: '(.+?)'").findall(OPEN)
    for link, label in match:
        if 'Auto' not in label:
            quality = '[B][COLOR orange]%s[/COLOR][/B]' %label
            res_quality.append(quality)
            stream_url.append(link)
    if len(match) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Quality',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                    url = stream_url[ret]
    else:
        url = re.compile("file: '(.+?)'").findall(OPEN)[0]
    url=url.replace(' ','%20').replace('amp;','')
    stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    
def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(cookie_file,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: 
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString
    
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))
                
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==101:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 3 : Get_Genres(url)
elif mode == 5 : Get_content(url) 
elif mode == 6 : Search()
elif mode == 7 : all_MENU()
elif mode == 8 : All_Genres(url)
elif mode == 9 : Get_show_content(url)
#elif mode == 10 : Get_links(url)
elif mode ==100: RESOLVE(url)
elif mode ==101: RESOLVE_tv(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















