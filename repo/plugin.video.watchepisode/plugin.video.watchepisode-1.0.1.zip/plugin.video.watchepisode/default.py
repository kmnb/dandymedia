# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.watchepisode'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'watchepisode'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://www.watchepisodes4.com/'


def Main_menu():
    addDir('[B][COLOR white]Popular Shows[/COLOR][/B]',BASEURL + 'home/popular-series',5,ART+'popular.jpg',FANART,'')
    addDir('[B][COLOR white]Trending Series[/COLOR][/B]','',8,ART+'trending.jpg',FANART,'')
    addDir('[B][COLOR white]New Series[/COLOR][/B]',BASEURL + 'home/new-series',5,ART+'new.jpg',FANART,'')
    addDir('[B][COLOR white]Browse Shows[/COLOR][/B]',BASEURL + 'home/series',4,ART+'browse.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]','',3,ART+'genres.jpg',FANART,'')
    addDir('[B][COLOR white]By Year[/COLOR][/B]','',7,ART+'year.jpg',FANART,'')
    addDir('[B][COLOR white]Search[/COLOR][/B]','url',6,ART+'search.jpg',FANART,'')
    setView('tvshows', 'tvshows-view')

def Get_Genres():
    OPEN = Open_Url(BASEURL + 'home/series')
    Regex = re.compile('<ul class="check-list filters" id="genres">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('data-genrename="(.+?)".+?<div class="cl-text">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'home/series?genres=%s'%url,4,ICON,FANART,'')
    setView('tvshows', 'default-view')
	
def Get_year():
    OPEN = Open_Url(BASEURL + 'home/series')
    Regex = re.compile('<ul class="check-list filters" id="years">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('data-year="(.+?)".+?<div class="cl-text">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'home/series?years=%s'%url,4,ICON,FANART,'')
    setView('tvshows', 'default-view')

def Get_main(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="wide-box">.+?<img src="(.+?)"></a>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            name = name.replace('&#39;','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    np = re.compile('</span>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '/page/' in url:
                    addDir('[B][COLOR blue]Go to page[/B][/COLOR] %s'%name,url,4,ART + 'nextpage.jpg',FANART,'')
    setView('tvshows', 'default-view')

def Get_trending():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('<div class="hrp-number".+?<a href="(.+?)" class="hrp-image" style="background-image: url\((.+?)\)"></a>.+?<a href=".+?" class="serie">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('\'','')
            name = name.replace('&#39;','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    setView('tvshows', 'default-view')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="grid-item">.+?<a href="(.+?)".+?title="(.+?)" src="(.+?)"></a>',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('&#39;','\'').replace('amp;','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    setView('tvshows', 'default-view')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="el-item ">.+?<a title="(.+?)" href="(.+?)".+?<div class="date">(.+?)</div>',re.DOTALL).findall(OPEN)
    for name,url,air in Regex:
            if 'Season 0' not in name:
                air=air.strip()
                name = name.replace('&#39;','\'').replace('amp;','')
                name = name[:-7]
                name = name + '  [COLOR red](' + air + ')[/COLOR]'
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    setView('tvshows', 'default-view')	
	
def Get_links(name,url):
    referer = url
    headers = {'Host': 'www.watchepisodes4.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="link-number">.+?<a href="(.+?)".+?data-hostname="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if 'vshare' not in name2:
            if 'vidzi.tv' not in name2: ###check later date
                addDir('[B][COLOR white]%s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    setView('tvshows', 'default-view')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + search 
                Get_episodes(url)
    

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
	

def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url) 
    host = re.compile('<a data-linkid=.+?target="_blank" href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    stream_url = evaluate(host)
    try:
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red]Dead Link[/COLOR],[COLOR white]Please Try Another[/COLOR] ,2000)")
	
def evaluate(host):
    try:
        if 'openload' in host:
            host = host.replace('https://openload.cc','https://openload.co')
            host = urlresolver.resolve(host)
        elif 'videoplayer.gq' in host:
            OPEN = Open_Url(host)
            host = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            host = host.replace('https://openload.cc','https://openload.co')
            host = urlresolver.resolve(host)
        elif urlresolver.HostedMediaFile(host):
            host = urlresolver.resolve(host)
        else:
            OPEN = Open_Url(host)
            holderpage = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            link = Open_Url(holderpage)
            host=re.compile('file: "(.+?)"').findall(link)[0]
    
        return host
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red]Dead Link[/COLOR],[COLOR white]Please Try Another[/COLOR] ,2000)")

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )

def OPEN_UrlRez():
        xbmcaddon.Addon('script.module.urlresolver').openSettings()

        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres()
elif mode == 7: Get_year()
elif mode == 4 : Get_main(url)
elif mode == 5 : Get_content(url)
elif mode == 8 : Get_trending()
elif mode == 2 : Get_episodes(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 200: OPEN_UrlRez()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
