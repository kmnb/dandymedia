# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.watchepisode/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'watchepisode'
VERSION = '0.0.6'
BASEURL = 'http://www.watchepisode.com/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Popular Shows[/COLOR][/B]',BASEURL + 'home/popular-series',5,ART+'popular.jpg',FANART,'')
    Menu('[B][COLOR white]Trending Series[/COLOR][/B]','',8,ART+'trending.jpg',FANART,'')
    Menu('[B][COLOR white]New Series[/COLOR][/B]',BASEURL + 'home/new-series',5,ART+'new.jpg',FANART,'')
    Menu('[B][COLOR white]Browse Shows[/COLOR][/B]',BASEURL + 'home/series',4,ART+'browse.jpg',FANART,'')
    Menu('[B][COLOR white]Genres[/COLOR][/B]','',3,ART+'genres.jpg',FANART,'')
    Menu('[B][COLOR white]By Year[/COLOR][/B]','',7,ART+'year.jpg',FANART,'')
    Menu('[B][COLOR white]Search[/COLOR][/B]','url',6,ART+'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_Genres():
    OPEN = Open_Url(BASEURL + 'home/series')
    Regex = re.compile('<ul class="check-list filters" id="genres">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('data-genrename="(.+?)".+?<div class="cl-text">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'home/series?genres=%s'%url,4,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_year():
    OPEN = Open_Url(BASEURL + 'home/series')
    Regex = re.compile('<ul class="check-list filters" id="years">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('data-year="(.+?)".+?<div class="cl-text">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'home/series?years=%s'%url,4,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_main(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="wide-box">.+?<img src="(.+?)"></a>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            name = name.replace('&#39;','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    np = re.compile('</span>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '/page/' in url:
                    Menu('[B][COLOR blue]Go to page[/B][/COLOR] %s'%name,url,4,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_trending():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('<div class="hrp-number".+?<a href="(.+?)" class="hrp-image" style="background-image: url\((.+?)\)"></a>.+?<a href=".+?" class="serie">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('\'','')
            name = name.replace('&#39;','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="grid-item">.+?<a href="(.+?)".+?title="(.+?)" src="(.+?)"></a>',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('&#39;','\'').replace('amp;','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="el-item ">.+?<a title="(.+?)" href="(.+?)">',re.DOTALL).findall(OPEN)
    for name,url in Regex:
            if 'Season 0' not in name:
                name = name.replace('&#39;','\'').replace('amp;','')
                name = name[:-7]
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')	
	
def Get_links(name,url):
    referer = url
    headers = {'Host': 'www.watch-episodes.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="link-number">.+?<a href="(.+?)".+?data-hostname="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if 'likeafool.com' in name2:
            name2 = name2.replace('likeafool.com','[COLOR red]GoogleLinks[/COLOR]')
            Menu('[B][COLOR white]%s[/COLOR][/B]'%name2,url,12,iconimage,FANART,name)
    for url,name2 in Regex:
            if 'likeafool.com' not in name2:
                        if 'funblr.com' not in name2:
                            if 'favour.me' not in name2:
                                if 'allmyvideos.net' not in name2:
                                        if 'filehoot.com' not in name2:
                                            if 'thevideobee.to' not in name2:
                                                if 'speedvid.net' not in name2:
                                                    if 'yourvideohost.com' not in name2:
                                                        Play('[B][COLOR white]%s[/COLOR][/B]'%name2,url,150,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def get_google(name,url):
    name = description
    OPEN = Open_Url(url)
    Regex = re.compile('<a data-linkid=.+?target="_blank" href="(.+?)"',re.DOTALL).findall(OPEN)
    for get_urls in Regex:
        get_urls = get_urls.replace('http://www.likeafool.com/files/','http://embed.likeafool.com/files/embed/')
        end_links = Open_Url(get_urls)
        vids = re.compile('file: "(.+?)".+?label: "(.+?)"',re.DOTALL).findall(end_links)
    for url,name2 in vids:  
            Play('[B][COLOR white]GoogleLink [COLOR red]in %s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + search 
                Get_episodes(url)
    

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR red]GoogleLink[/COLOR],[COLOR white]Resolving[/COLOR] ,2000)")
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def alt_resolve(name,url,iconimage,description):
    name = description
    OPEN = Open_Url(url)
    xbmc.executebuiltin("XBMC.Notification([COLOR red]Watch Episodes[/COLOR],[COLOR white]Resolving Link[/COLOR] ,2000)") 
    url = re.compile('<a data-linkid=.+?target="_blank" href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    url = url.replace('https://openload.cc','https://openload.co').replace('http://www.lolzor.com/bach/','http://www.lolzor.com/bach/embed/').replace('http://vodlocker.city/','http://vodlocker.com/').replace('http://www.mycollection.net/bishop/','http://www.mycollection.net/bishop/embed/').replace('http://www.adhqmedia.com/duke/','http://www.adhqmedia.com/duke/embed/').replace('http://www.vidbaba.com/isiloon/','http://www.vidbaba.com/isiloon/embed/').replace('http://www.gagomatic.com/talos/','http://www.gagomatic.com/talos/embed/')
    if 'lolzor' in url:
        link2 = Open_Url(url)
        url = re.compile('file: "(.+?)"').findall(link2)[0]
        play=urlresolver.HostedMediaFile(url).resolve()
    elif 'mycollection' in url:
        link2 = Open_Url(url)
        url = re.compile('file: "(.+?)"').findall(link2)[0]
        play=urlresolver.HostedMediaFile(url).resolve()
    elif 'adhqmedia' in url:
        link2 = Open_Url(url)
        url = re.compile('file: "(.+?)"').findall(link2)[0]
        play=urlresolver.HostedMediaFile(url).resolve()
    elif 'vidbaba' in url:
        link2 = Open_Url(url)
        url = re.compile('file: "(.+?)"').findall(link2)[0]
        play=urlresolver.HostedMediaFile(url).resolve()
    elif 'gagomatic' in url:
        link2 = Open_Url(url)
        url = re.compile('file: "(.+?)"').findall(link2)[0]
        play=urlresolver.HostedMediaFile(url).resolve()
    else:
        play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres()
elif mode == 7: Get_year()
elif mode == 4 : Get_main(url)
elif mode == 5 : Get_content(url)
elif mode == 8 : Get_trending()
elif mode == 2 : Get_episodes(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 12 : get_google(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 150 : alt_resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
