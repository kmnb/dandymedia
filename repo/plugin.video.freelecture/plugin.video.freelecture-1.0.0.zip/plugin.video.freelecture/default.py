# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,xbmcaddon
from addon.common.addon import Addon
addon_id='plugin.video.freelecture'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'freelecture'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://freevideolectures.com/'



def Home_Menu():
    addDir('[B][COLOR white]Programming & Web Development[/COLOR][/B]','',3,ART + 'pwdev.jpg',FANART,'')
    addDir('[B][COLOR white]Maths & Sciences[/COLOR][/B]','',4,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Engineering[/COLOR][/B]','',5,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Business & Management[/COLOR][/B]','',6,ART + 'bandm.jpg',FANART,'')
    addDir('[B][COLOR white]Others[/COLOR][/B]','',7,ART + 'others.jpg',FANART,'')

def PWD():
    addDir('[B][COLOR white]Computer Science[/COLOR][/B]',BASEURL +'Subject/Computer-Science',1,ART + 'pwdev.jpg',FANART,'')
    addDir('[B][COLOR white]Networking[/COLOR][/B]',BASEURL +'Subject/Networking',1,ART + 'pwdev.jpg',FANART,'')
    addDir('[B][COLOR white]Web Designing[/COLOR][/B]',BASEURL +'Subject/Web-Designing',1,ART + 'pwdev.jpg',FANART,'')
    addDir('[B][COLOR white]Data Structures[/COLOR][/B]',BASEURL +'Subject/Data-Structures',1,ART + 'pwdev.jpg',FANART,'')
    addDir('[B][COLOR white]Programming[/COLOR][/B]',BASEURL +'Subject/Programming',1,ART + 'pwdev.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Math_Sc():
    addDir('[B][COLOR white]Anatomy Physiology[/COLOR][/B]',BASEURL +'Subject/Anatomy-Physiology',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Bio Technology[/COLOR][/B]',BASEURL +'Subject/Bio-Technology',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Chemistry[/COLOR][/B]',BASEURL +'Subject/Chemistry',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Genetics[/COLOR][/B]',BASEURL +'Subject/Genetics',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Health Sciences[/COLOR][/B]',BASEURL +'Subject/Health-Sciences',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Mathmatics[/COLOR][/B]',BASEURL +'Subject/Mathematics',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Medicine[/COLOR][/B]',BASEURL +'Subject/Medicine',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Physics[/COLOR][/B]',BASEURL +'Subject/Physics',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Calculus[/COLOR][/B]',BASEURL +'Subject/Calculus',1,ART + 'mands.jpg',FANART,'')
    addDir('[B][COLOR white]Biology[/COLOR][/B]',BASEURL +'Subject/Biology',1,ART + 'mands.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Eng():
    addDir('[B][COLOR white]Astronomy Aerospace[/COLOR][/B]',BASEURL +'Subject/Astronomy-Aerospace',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Electronics[/COLOR][/B]',BASEURL +'Subject/Electronics',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Mechanical[/COLOR][/B]',BASEURL +'Subject/Mechanical',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Signals Systems[/COLOR][/B]',BASEURL +'Subject/Signals-Systems',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]VLSI and ASIC Design[/COLOR][/B]',BASEURL +'Subject/VLSI-and-ASIC-Design',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Electrical Engineering[/COLOR][/B]',BASEURL +'Subject/Electrical-Engineering',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Civil Engineering[/COLOR][/B]',BASEURL +'Subject/Civil-Engineering',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Metallurgy and Material Science[/COLOR][/B]',BASEURL +'Subject/Metallurgy-and-Material-Science',1,ART + 'engin.jpg',FANART,'')
    addDir('[B][COLOR white]Ocean Engineering[/COLOR][/B]',BASEURL +'Subject/Ocean-Engineering',1,ART + 'engin.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Other():
    addDir('[B][COLOR white]Economics[/COLOR][/B]',BASEURL +'Subject/Economics',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Law[/COLOR][/B]',BASEURL +'Subject/Law',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Philosophy[/COLOR][/B]',BASEURL +'Subject/Philosophy',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Phychology[/COLOR][/B]',BASEURL +'Subject/Psychology',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Social Sciences[/COLOR][/B]',BASEURL +'Subject/Social-Sciences',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]History[/COLOR][/B]',BASEURL +'Subject/History',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Litrature[/COLOR][/B]',BASEURL +'Subject/Literature',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Languages[/COLOR][/B]',BASEURL +'Subject/Languages',1,ART + 'others.jpg',FANART,'')
    addDir('[B][COLOR white]Other Courses[/COLOR][/B]',BASEURL +'Subject/Other-Courses',1,ART + 'others.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def B_Man():
    addDir('[B][COLOR white]Business Management 1234[/COLOR][/B]',BASEURL +'Subject/Business-Management',1,ART + 'bandm.jpg',FANART,'')
    addDir('[B][COLOR white]Entrepreneurship[/COLOR][/B]',BASEURL +'Subject/Entrepreneurship',1,ART + 'bandm.jpg',FANART,'')
    addDir('[B][COLOR white]Communication Skills[/COLOR][/B]',BASEURL +'Subject/Communication-Skills',1,ART + 'bandm.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Main_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="cs-courses courses-grid">.+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        icon = icon.replace(' ','%20')
        addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,2,icon,FANART,'')
    np = re.compile('<li><a href="(.+?)" class="footer_paginate">(.+?)</a><li>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if 'NEXT' in name:
                    addDir('[B][COLOR red]Next Page >>>[/COLOR][/B]',url,1,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')					

def Second_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="lecture_menu">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li.+?><a href="(.+?)".+?>(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.replace('\\\'','\'')
        addDir(name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
        
		

def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    if 'data-attr=' in OPEN:
        url = re.compile("data-attr='(.+?)'",re.DOTALL).findall(OPEN)[0]
        url = url.replace('http://www.youtube.com/watch?v=','plugin://plugin.video.youtube/play/?video_id=')   
    elif 'flashvars=' in OPEN:
        try:
            url = re.compile("flashvars='config=(.+?)'",re.DOTALL).findall(OPEN)[0]
            url = url.replace('/embeded_config.xml%3Fmid%3D','/repository/')
            url = url + '_site.mp4'
        except:pass
    else:
        xbmc.executebuiltin("XBMC.Notification([COLOR red]Sorry[/COLOR],[COLOR cornflowerblue]No Playable Link[/COLOR],2000)")
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
    liz.setProperty('IsPlayable','true')
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Home_Menu()
elif mode == 1 : Main_Menu(url)
elif mode == 2 : Second_Menu(url)
elif mode == 3 : PWD()
elif mode == 4 : Math_Sc()
elif mode == 5 : Eng()
elif mode == 6 : B_Man()
elif mode == 7 : Other()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
