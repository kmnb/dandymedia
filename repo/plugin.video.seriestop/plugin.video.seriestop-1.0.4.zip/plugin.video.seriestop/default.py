# -*- coding: utf-8 -*-
import urllib2 , urllib , xbmcgui , xbmcaddon , xbmcplugin , xbmc , re , sys , os , dandy
import urlresolver
from addon . common . addon import Addon
import requests
oo000 = requests . session ( )
ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
oOOo = 'plugin.video.seriestop'
O0 = xbmcaddon . Addon ( id = oOOo )
o0O = Addon ( oOOo , sys . argv )
iI11I1II1I1I = O0 . getAddonInfo ( 'name' )
oooo = xbmcaddon . Addon ( )
iIIii1IIi = oooo . getAddonInfo ( 'path' )
o0OO00 = oooo . getAddonInfo ( 'icon' )
oo = oooo . getAddonInfo ( 'fanart' )
i1iII1IiiIiI1 = 'seriestop'
iIiiiI1IiI1I1 = oooo . getAddonInfo ( 'version' )
o0OoOoOO00 = iIIii1IIi + "/resources/icons/"
I11i = 'https://series-top.com/'
o0OoOoOO00 = iIIii1IIi + "/resources/icons/"
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
if 8 - 8: Oo / iII11iiIII111 % iiiIIii1I1Ii . O00oOoOoO0o0O
def II1ii1II1iII1 ( ) :
 Ii ( '[B][COLOR red]UK Soaps[/COLOR][/B]' , '' , 2 , o0OoOoOO00 + 'soaps.jpg' , oo , '' )
 Ii ( '[B][COLOR blue]All Shows (Newest order)[/COLOR][/B]' , I11i + 'tv-shows' , 4 , o0OoOoOO00 + 'newest.jpg' , oo , '' )
 Ii ( '[B][COLOR blue]All Shows (Alphabetical)[/COLOR][/B]' , I11i + 'tv-shows/abc' , 4 , o0OoOoOO00 + 'alpha.jpg' , oo , '' )
 Ii ( '[B][COLOR blue]All Shows (IMDB Rating)[/COLOR][/B]' , I11i + 'tv-shows/imdb_rating' , 4 , o0OoOoOO00 + 'imdb.jpg' , oo , '' )
 Ii ( '[B][COLOR blue]Search[/COLOR][/B]' , 'url' , 5 , o0OoOoOO00 + 'search.jpg' , oo , '' )
 Oo0o = OOO0o0o ( I11i + 'tv-shows' )
 Ii1iI = re . compile ( '/tv-tags/(.+?)>' , re . DOTALL ) . findall ( Oo0o )
 for OoI1Ii11I1Ii1i in Ii1iI :
  OoI1Ii11I1Ii1i = OoI1Ii11I1Ii1i . replace ( '"' , '' ) . replace ( '\'' , '' )
  Ooo = OoI1Ii11I1Ii1i
  Ooo = Ooo . replace ( '-' , ' ' ) . title ( )
  Ii ( '[B][COLOR white]%s[/COLOR][/B]' % Ooo , I11i + 'tv-tags/%s' % OoI1Ii11I1Ii1i , 4 , o0OO00 , oo , '' )
  if 56 - 56: ooO00oOoo - O0OOo
  if 8 - 8: Oooo0000 * i1IIi11111i / I11i1i11i1I % ooIiII1I1i1i1ii / oOOOo0o0O + OOoOoo00oo
def iiI11 ( ) :
 Ii ( '[B][COLOR red]Coronation Street[/COLOR][/B]' , I11i + 'show/coronation-street' , 3 , 'http://thetvdb.com/banners/_cache/posters/71565-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71565-2.jpg' , '' )
 Ii ( '[B][COLOR red]Eastenders[/COLOR][/B]' , I11i + 'show/eastenders' , 3 , 'http://thetvdb.com/banners/_cache/posters/71753-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71753-7.jpg' , '' )
 Ii ( '[B][COLOR red]Emmerdale[/COLOR][/B]' , I11i + 'show/emmerdale' , 3 , 'http://thetvdb.com/banners/_cache/posters/77715-2.jpg' , 'http://thetvdb.com/banners/fanart/original/77715-3.jpg' , '' )
 Ii ( '[B][COLOR red]Casualty[/COLOR][/B]' , I11i + 'show/casualty' , 3 , 'http://thetvdb.com/banners/_cache/posters/71756-4.jpg' , 'http://thetvdb.com/banners/fanart/original/71756-2.jpg' , '' )
 Ii ( '[B][COLOR red]Holby City[/COLOR][/B]' , I11i + 'show/holby-city' , 3 , 'http://thetvdb.com/banners/_cache/posters/77235-1.jpg' , 'http://thetvdb.com/banners/fanart/original/77235-3.jpg' , '' )
 Ii ( '[B][COLOR red]Hollyoaks[/COLOR][/B]' , I11i + 'show/hollyoaks' , 3 , 'http://thetvdb.com/banners/_cache/posters/78006-1.jpg' , 'http://thetvdb.com/banners/fanart/original/78006-1.jpg' , '' )
 Ii ( '[B][COLOR red]Doctors[/COLOR][/B]' , I11i + 'show/doctors' , 3 , 'http://thetvdb.com/banners/_cache/posters/83729-2.jpg' , 'http://thetvdb.com/banners/fanart/original/83729-1.jpg' , '' )
 Ii ( '[B][COLOR red]Home & Away[/COLOR][/B]' , I11i + 'show/home-away' , 3 , 'http://thetvdb.com/banners/_cache/posters/71890-2.jpg' , 'http://thetvdb.com/banners/fanart/original/71890-1.jpg' , '' )
 Ii ( '[B][COLOR red]Neighbours[/COLOR][/B]' , I11i + 'show/neighbours' , 3 , 'http://thetvdb.com/banners/_cache/posters/76719-2.jpg' , 'http://thetvdb.com/banners/fanart/original/76719-2.jpg' , '' )
 if 91 - 91: oOOOO / i1iiIII111ii + iiIIi1IiIi11 . i1Ii
def I111I11 ( url ) :
 Oo0o = OOO0o0o ( url )
 O0O00Ooo = url
 OOoooooO = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : O0O00Ooo }
 Ii1iI = re . compile ( '/show/(.+?) .+?/templates/(.+?);zc' , re . DOTALL ) . findall ( Oo0o )
 for url , i1iIIIiI1I in Ii1iI :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  Ooo = url
  Ooo = Ooo . replace ( '-' , ' ' ) . title ( )
  i1iIIIiI1I = i1iIIIiI1I . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
  i1iIIIiI1I = i1iIIIiI1I + '|' + urllib . urlencode ( OOoooooO )
  Ii ( '[B][COLOR white]%s[/COLOR][/B]' % Ooo , I11i + 'show/%s' % url , 3 , I11i + 'templates/%s' % i1iIIIiI1I , oo , '' )
 OOoO000O0OO = re . compile ( '<li><a href="(.+?)">(.+?)</a></li> ' , re . DOTALL ) . findall ( Oo0o )
 for url , Ooo in OOoO000O0OO :
  if '&raquo;' in Ooo :
   Ii ( '[B][COLOR blue]Next Page>>>[/COLOR][/B]' , url , 4 , o0OoOoOO00 + 'nextpage.jpg' , oo , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 23 - 23: OOooo000oo0 + iiiIIii1I1Ii
def oOo ( url ) :
 Oo0o = OOO0o0o ( url )
 O0O00Ooo = url
 OOoooooO = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : O0O00Ooo }
 Ii1iI = re . compile ( 'data.orig.+?/show/(.+?) ' , re . DOTALL ) . findall ( Oo0o )
 for url in Ii1iI :
  url = url . replace ( '"' , '' ) . replace ( '\'' , '' )
  Ooo = url
  Ooo = Ooo . split ( '/' ) [ 0 ]
  Ooo = Ooo . replace ( '-' , ' ' ) . title ( )
  Ii ( '[B][COLOR white]%s[/COLOR][/B]' % Ooo , I11i + 'show/%s' % url , 1 , oOoOoO , oo , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 6 - 6: iiiIIii1I1Ii / O00oOoOoO0o0O % OOoOoo00oo
 if 84 - 84: OOooo000oo0 . Oooo0000
def o0O00oooo ( name , url ) :
 Oo0o = OOO0o0o ( url )
 O0O00Ooo = url
 OOoooooO = { 'Host' : 'series-top.com' , 'User-Agent' : ii , 'Referer' : O0O00Ooo }
 Ii1iI = re . compile ( '69-75-75-71(.+?)\'' , re . DOTALL ) . findall ( Oo0o )
 for O00o in Ii1iI :
  O00o = '69-75-75-71' + O00o
  O00o = O00o . replace ( '-' , ' ' )
  try :
   url = bytearray . fromhex ( O00o ) . decode ( )
  except TypeError :
   url = bytearray . fromhex ( unicode ( O00o ) ) . decode ( )
  url = O00 ( url )
  if 11 - 11: iiiIIii1I1Ii
  O0o0Oo = url . split ( '//' ) [ 1 ] . replace ( 'www.' , '' )
  O0o0Oo = O0o0Oo . split ( '/' ) [ 0 ] . split ( '.' ) [ 0 ] . title ( )
  if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   Ii ( '[B][COLOR white]%s[/COLOR][/B]' % O0o0Oo , url , 100 , oOoOoO , oo , name )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 78 - 78: ii1IiI1i - OOoOoo00oo * ooO00oOoo + Oooo0000 + oOOOO + oOOOO
def O00 ( url ) :
 url = url . replace ( 'a' , 'z' ) . replace ( 'b' , 'a' ) . replace ( 'c' , 'b' ) . replace ( 'd' , 'c' ) . replace ( 'e' , 'd' ) . replace ( 'f' , 'e' )
 url = url . replace ( 'g' , 'f' ) . replace ( 'h' , 'g' ) . replace ( 'i' , 'h' ) . replace ( 'j' , 'i' ) . replace ( 'k' , 'j' ) . replace ( 'l' , 'k' )
 url = url . replace ( 'm' , 'l' ) . replace ( 'n' , 'm' ) . replace ( 'o' , 'n' ) . replace ( 'p' , 'o' ) . replace ( 'q' , 'p' ) . replace ( 'r' , 'q' )
 url = url . replace ( 's' , 'r' ) . replace ( 't' , 's' ) . replace ( 'u' , 't' ) . replace ( 'v' , 'u' ) . replace ( 'w' , 'v' ) . replace ( 'x' , 'w' ) . replace ( 'y' , 'x' ) . replace ( 'z' , 'y' )
 if 11 - 11: oOOOO - ooO00oOoo % i1Ii % oOOOO / O0OOo - ooO00oOoo
 url = url . replace ( '.' , '-' ) . replace ( '/' , '.' ) . replace ( '0' , '/' ) . replace ( '1' , '0' ) . replace ( '2' , '1' ) . replace ( '3' , '2' ) . replace ( '4' , '3' ) . replace ( '5' , '4' )
 url = url . replace ( '6' , '5' ) . replace ( '7' , '6' ) . replace ( '8' , '7' ) . replace ( '9' , '8' ) . replace ( ':' , '9' )
 url = url . replace ( ';' , ':' ) . replace ( '_' , '' ) . replace ( '`' , '_' ) . replace ( '{' , 'z' )
 if 74 - 74: oOOOO * i1
 url = url . replace ( 'A' , 'Z' ) . replace ( 'B' , 'A' ) . replace ( 'C' , 'B' ) . replace ( 'D' , 'C' ) . replace ( 'E' , 'D' ) . replace ( 'F' , 'E' )
 url = url . replace ( 'G' , 'F' ) . replace ( 'H' , 'G' ) . replace ( 'I' , 'H' ) . replace ( 'J' , 'I' ) . replace ( 'K' , 'J' ) . replace ( 'L' , 'K' )
 url = url . replace ( 'M' , 'L' ) . replace ( 'N' , 'M' ) . replace ( 'O' , 'N' ) . replace ( 'P' , 'O' ) . replace ( 'Q' , 'P' ) . replace ( 'R' , 'Q' )
 url = url . replace ( 'S' , 'R' ) . replace ( 'T' , 'S' ) . replace ( 'U' , 'T' ) . replace ( 'V' , 'U' ) . replace ( 'W' , 'V' ) . replace ( 'X' , 'W' )
 url = url . replace ( 'Y' , 'Z' ) . replace ( 'Z' , 'Y' )
 return url
 if 89 - 89: I11i1i11i1I + O00oOoOoO0o0O
def Ii1I ( ) :
 Oo0o0 = xbmc . Keyboard ( '' , 'Search' )
 Oo0o0 . doModal ( )
 if ( Oo0o0 . isConfirmed ( ) ) :
  III1ii1iII = Oo0o0 . getText ( ) . replace ( ' ' , '-' )
  OoI1Ii11I1Ii1i = I11i + 'show/' + III1ii1iII
  Oo0o = OOO0o0o ( OoI1Ii11I1Ii1i )
  Ii1iI = re . compile ( '<div class="post_show_left">.*?<a href="(.*?)" rel="bookmark" title="(.*?)">.*?<img class="img_poster" src="(.*?)" alt=".*?"/>' , re . DOTALL ) . findall ( Oo0o )
  for OoI1Ii11I1Ii1i , Ooo , i1iIIIiI1I in Ii1iI :
   i1iIIIiI1I = i1iIIIiI1I . replace ( 'amp;' , '' ) . replace ( 'w=120&h=180' , 'w=240&h=360' )
   Ii ( Ooo , OoI1Ii11I1Ii1i , 3 , i1iIIIiI1I , oo , '' )
   if 54 - 54: iiiIIii1I1Ii % iII11iiIII111 % iII11iiIII111
   if 13 - 13: Oooo0000 . OOoOoo00oo
   if 19 - 19: oOOOo0o0O + i1Ii
   if 53 - 53: IIIiiIIii . Oo
   if 18 - 18: Oooo0000
   if 28 - 28: ooIiII1I1i1i1ii - i1iiIII111ii . i1iiIII111ii + O0OOo - IIIiiIIii + i1
def OOO0o0o ( url ) :
 OOoooooO = { }
 OOoooooO [ 'User-Agent' ] = ii
 oOoOooOo0o0 = oo000 . get ( url , headers = OOoooooO , verify = False ) . text
 oOoOooOo0o0 = oOoOooOo0o0 . encode ( 'ascii' , 'ignore' )
 return oOoOooOo0o0
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 61 - 61: Oooo0000 / ooO00oOoo + i1Ii * I11i1i11i1I / I11i1i11i1I
def Ii ( name , url , mode , iconimage , fanart , description ) :
 OoOo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 iI = True
 o00O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o00O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 o00O . setProperty ( 'fanart_image' , fanart )
 if mode == 100 :
  o00O . setProperty ( "IsPlayable" , "true" )
  iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOo , listitem = o00O , isFolder = False )
 else :
  iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOo , listitem = o00O , isFolder = True )
 return iI
 if 69 - 69: I11i1i11i1I % iiIIi1IiIi11 - Oooo0000 + iiIIi1IiIi11 - i1 % IIIiiIIii
def Iii111II ( name , url , iconimage , description ) :
 if 9 - 9: ooO00oOoo
 if 33 - 33: i1Ii . oOOOO
 if 58 - 58: ooIiII1I1i1i1ii * OOooo000oo0 / O0OOo % iiIIi1IiIi11 - i1IIi11111i / I11i1i11i1I
 if 50 - 50: iiiIIii1I1Ii
 if 34 - 34: iiiIIii1I1Ii * iII11iiIII111 % oOOOO * O0OOo - iiiIIii1I1Ii
 if 33 - 33: Oooo0000 + ooIiII1I1i1i1ii * ooO00oOoo - O00oOoOoO0o0O / I11i1i11i1I % OOoOoo00oo
 if 21 - 21: ooO00oOoo * ii1IiI1i % I11i1i11i1I * Oo
 if 16 - 16: i1 - iiIIi1IiIi11 * ii1IiI1i + oOOOO
 if 50 - 50: iII11iiIII111 - i1Ii * i1IIi11111i / iiIIi1IiIi11 + Oooo0000
 if 88 - 88: OOoOoo00oo / iiIIi1IiIi11 + oOOOO - iII11iiIII111 / i1Ii - O0OOo
 if 15 - 15: i1IIi11111i + O0OOo - IIIiiIIii / ooIiII1I1i1i1ii
 if 58 - 58: OOooo000oo0 % oOOOo0o0O
 if 71 - 71: ooIiII1I1i1i1ii + i1Ii % OOooo000oo0 + i1IIi11111i - i1iiIII111ii
 if 88 - 88: O0OOo - ooO00oOoo % ooIiII1I1i1i1ii
 if 16 - 16: iiiIIii1I1Ii * I11i1i11i1I % i1iiIII111ii
 if 86 - 86: iiiIIii1I1Ii + OOoOoo00oo % OOooo000oo0 * I11i1i11i1I . i1Ii * oOOOo0o0O
 if 44 - 44: I11i1i11i1I
 if 88 - 88: iiIIi1IiIi11 % OOoOoo00oo . iII11iiIII111
 if 38 - 38: Oooo0000
 if 57 - 57: i1 / I11i1i11i1I * iiIIi1IiIi11 / O0OOo . iII11iiIII111
 if 26 - 26: oOOOO
 if 91 - 91: ooO00oOoo . i1IIi11111i + ooO00oOoo - oOOOO / IIIiiIIii
 if 39 - 39: i1IIi11111i / i1Ii - iII11iiIII111
 if 98 - 98: i1IIi11111i / oOOOo0o0O % I11i1i11i1I . O0OOo
 if 91 - 91: I11i1i11i1I % O00oOoOoO0o0O
 if 64 - 64: oOOOo0o0O % oOOOO - iiIIi1IiIi11 - I11i1i11i1I
 if 31 - 31: oOOOo0o0O - iII11iiIII111 . oOOOo0o0O
 if 18 - 18: Oooo0000
 if 98 - 98: oOOOO * oOOOO / oOOOO + oOOOo0o0O
 if 34 - 34: i1Ii
 if 15 - 15: oOOOo0o0O * i1Ii * O00oOoOoO0o0O % OOooo000oo0 % O0OOo - ooIiII1I1i1i1ii
 if 68 - 68: iiIIi1IiIi11 % Oo . i1iiIII111ii . i1IIi11111i
 if 92 - 92: oOOOO . iiIIi1IiIi11
 if 31 - 31: iiIIi1IiIi11 . O0OOo / i1
 if 89 - 89: O0OOo
 if 68 - 68: ooO00oOoo * IIIiiIIii % i1 + ooO00oOoo + i1Ii
 if 4 - 4: i1Ii + i1 * ooIiII1I1i1i1ii
 if 55 - 55: O00oOoOoO0o0O + ii1IiI1i / O0OOo * I11i1i11i1I - OOooo000oo0 - OOoOoo00oo
 try :
  ii1ii1ii = urlresolver . resolve ( url )
  o00O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
  o00O . setInfo ( type = "Video" , infoLabels = { "Title" : description } )
  o00O . setProperty ( "IsPlayable" , "true" )
  o00O . setPath ( ii1ii1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00O )
 except : pass
 if 91 - 91: i1iiIII111ii
def iiIii ( ) :
 ooo0O = [ ]
 oOoO0o00OO0 = sys . argv [ 2 ]
 if len ( oOoO0o00OO0 ) >= 2 :
  i1I1ii = sys . argv [ 2 ]
  oOOo0 = i1I1ii . replace ( '?' , '' )
  if ( i1I1ii [ len ( i1I1ii ) - 1 ] == '/' ) :
   i1I1ii = i1I1ii [ 0 : len ( i1I1ii ) - 2 ]
  oo00O00oO = oOOo0 . split ( '&' )
  ooo0O = { }
  for iIiIIIi in range ( len ( oo00O00oO ) ) :
   ooo00OOOooO = { }
   ooo00OOOooO = oo00O00oO [ iIiIIIi ] . split ( '=' )
   if ( len ( ooo00OOOooO ) ) == 2 :
    ooo0O [ ooo00OOOooO [ 0 ] ] = ooo00OOOooO [ 1 ]
    if 67 - 67: oOOOo0o0O * I11i1i11i1I * i1IIi11111i + ooIiII1I1i1i1ii / Oo
 return ooo0O
 if 11 - 11: OOoOoo00oo + oOOOO - i1Ii * I11i1i11i1I % OOooo000oo0 - iiIIi1IiIi11
i1I1ii = iiIii ( )
OoI1Ii11I1Ii1i = None
Ooo = None
oOoOoO = None
o0oO = None
IIiIi1iI = None
i1IiiiI1iI = None
if 49 - 49: OOoOoo00oo / ooO00oOoo . iII11iiIII111
if 68 - 68: OOooo000oo0 % i1IIi11111i + OOooo000oo0
try :
 OoI1Ii11I1Ii1i = urllib . unquote_plus ( i1I1ii [ "url" ] )
except :
 pass
try :
 Ooo = urllib . unquote_plus ( i1I1ii [ "name" ] )
except :
 pass
try :
 oOoOoO = urllib . unquote_plus ( i1I1ii [ "iconimage" ] )
except :
 pass
try :
 o0oO = int ( i1I1ii [ "mode" ] )
except :
 pass
try :
 IIiIi1iI = urllib . unquote_plus ( i1I1ii [ "fanart" ] )
except :
 pass
try :
 i1IiiiI1iI = urllib . unquote_plus ( i1I1ii [ "description" ] )
except :
 pass
 if 31 - 31: iII11iiIII111 . iiiIIii1I1Ii
 if 1 - 1: O00oOoOoO0o0O / Oooo0000 % oOOOO * i1iiIII111ii . OOooo000oo0
print str ( i1iII1IiiIiI1 ) + ': ' + str ( iIiiiI1IiI1I1 )
print "Mode: " + str ( o0oO )
print "URL: " + str ( OoI1Ii11I1Ii1i )
print "Name: " + str ( Ooo )
print "IconImage: " + str ( oOoOoO )
if 2 - 2: i1IIi11111i * oOOOo0o0O - ii1IiI1i + iiiIIii1I1Ii . I11i1i11i1I % oOOOO
if 92 - 92: oOOOO
if o0oO == None : II1ii1II1iII1 ( )
elif o0oO == 1 : o0O00oooo ( Ooo , OoI1Ii11I1Ii1i )
elif o0oO == 2 : iiI11 ( )
elif o0oO == 3 : oOo ( OoI1Ii11I1Ii1i )
elif o0oO == 4 : I111I11 ( OoI1Ii11I1Ii1i )
elif o0oO == 5 : Ii1I ( )
elif o0oO == 100 : Iii111II ( Ooo , OoI1Ii11I1Ii1i , oOoOoO , i1IiiiI1iI )
if 25 - 25: O00oOoOoO0o0O - iiiIIii1I1Ii / IIIiiIIii / Oooo0000
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
