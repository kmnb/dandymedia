# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui,xbmcaddon, xbmcplugin, xbmc, re, sys, os, dandy
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.seriestop'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'seriestop'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'https://series-top.com/'
ART = ADDON_PATH + "/resources/icons/"

def Home_Menu():
    addDir('[B][COLOR red]UK Soaps[/COLOR][/B]','',2,ART + 'soaps.jpg',FANART,'')
    addDir('[B][COLOR blue]All Shows (Newest order)[/COLOR][/B]',BASEURL + 'tv-shows',4,ART + 'newest.jpg',FANART,'')
    addDir('[B][COLOR blue]All Shows (Alphabetical)[/COLOR][/B]',BASEURL + 'tv-shows/abc',4,ART + 'alpha.jpg',FANART,'')
    addDir('[B][COLOR blue]All Shows (IMDB Rating)[/COLOR][/B]',BASEURL + 'tv-shows/imdb_rating',4,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR blue]Search[/COLOR][/B]','url',5,ART + 'search.jpg',FANART,'')
    OPEN = Open_Url(BASEURL + 'tv-shows')
    Regex = re.compile('/tv-tags/(.+?)>',re.DOTALL).findall(OPEN)
    for url in Regex:
            url=url.replace('"','').replace('\'','')
            name = url
            name=name.replace('-',' ').title()
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'tv-tags/%s'%url,4,ICON,FANART,'')

	
def Soaps_Menu():
    addDir('[B][COLOR red]Coronation Street[/COLOR][/B]',BASEURL + 'show/coronation-street',3,'http://thetvdb.com/banners/_cache/posters/71565-2.jpg','http://thetvdb.com/banners/fanart/original/71565-2.jpg','')
    addDir('[B][COLOR red]Eastenders[/COLOR][/B]',BASEURL + 'show/eastenders',3,'http://thetvdb.com/banners/_cache/posters/71753-2.jpg','http://thetvdb.com/banners/fanart/original/71753-7.jpg','')
    addDir('[B][COLOR red]Emmerdale[/COLOR][/B]',BASEURL + 'show/emmerdale',3,'http://thetvdb.com/banners/_cache/posters/77715-2.jpg','http://thetvdb.com/banners/fanart/original/77715-3.jpg','')
    addDir('[B][COLOR red]Casualty[/COLOR][/B]',BASEURL + 'show/casualty',3,'http://thetvdb.com/banners/_cache/posters/71756-4.jpg','http://thetvdb.com/banners/fanart/original/71756-2.jpg','')
    addDir('[B][COLOR red]Holby City[/COLOR][/B]',BASEURL + 'show/holby-city',3,'http://thetvdb.com/banners/_cache/posters/77235-1.jpg','http://thetvdb.com/banners/fanart/original/77235-3.jpg','')
    addDir('[B][COLOR red]Hollyoaks[/COLOR][/B]',BASEURL + 'show/hollyoaks',3,'http://thetvdb.com/banners/_cache/posters/78006-1.jpg','http://thetvdb.com/banners/fanart/original/78006-1.jpg','')
    addDir('[B][COLOR red]Doctors[/COLOR][/B]',BASEURL + 'show/doctors',3,'http://thetvdb.com/banners/_cache/posters/83729-2.jpg','http://thetvdb.com/banners/fanart/original/83729-1.jpg','')
    addDir('[B][COLOR red]Home & Away[/COLOR][/B]',BASEURL + 'show/home-away',3,'http://thetvdb.com/banners/_cache/posters/71890-2.jpg','http://thetvdb.com/banners/fanart/original/71890-1.jpg','')
    addDir('[B][COLOR red]Neighbours[/COLOR][/B]',BASEURL + 'show/neighbours',3,'http://thetvdb.com/banners/_cache/posters/76719-2.jpg','http://thetvdb.com/banners/fanart/original/76719-2.jpg','')
	
def Shows_Menu(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'series-top.com', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('/show/(.+?) .+?/templates/(.+?);zc',re.DOTALL).findall(OPEN)
    for url,icon in Regex:
            url = url.replace('"','').replace('\'','')
            name = url
            name = name.replace('-',' ').title()
            icon = icon.replace('amp;','').replace('w=120&h=180','w=240&h=360').replace('w=120&h=180','w=240&h=360')
            icon = icon + '|' + urllib.urlencode(headers)
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'show/%s'%url,3,BASEURL + 'templates/%s'%icon,FANART,'')
    np = re.compile('<li><a href="(.+?)">(.+?)</a></li> ',re.DOTALL).findall(OPEN)
    for url,name in np:
            if '&raquo;' in name:
                    addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,4,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Main_Menu(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'series-top.com', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('data.orig.+?/show/(.+?) ',re.DOTALL).findall(OPEN)
    for url in Regex:
            url = url.replace('"','').replace('\'','')
            name = url
            name = name.split('/')[0]
            name = name.replace('-',' ').title()
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + 'show/%s'%url,1,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
		
	
def Second_Menu(name,url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'series-top.com', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('68-74-74-70(.+?)\'',re.DOTALL).findall(OPEN)
    for hex_string in Regex:
            hex_string = '68-74-74-70' + hex_string
            hex_string = hex_string.replace('-', ' ')
            try:
                url = bytearray.fromhex(hex_string).decode()
            except TypeError:
                url = bytearray.fromhex(unicode(hex_string)).decode()
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            if urlresolver.HostedMediaFile(url).valid_url():
                if 'Vidzi' not in name2:
                    addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + 'show/' + search
                OPEN = Open_Url(url)
                Regex = re.compile('<div class="post_show_left">.*?<a href="(.*?)" rel="bookmark" title="(.*?)">.*?<img class="img_poster" src="(.*?)" alt=".*?"/>',re.DOTALL).findall(OPEN)
                for url, name, icon in Regex:
                        icon = icon.replace('amp;','').replace('w=120&h=180','w=240&h=360')
                        addDir(name,url,3,icon,FANART,'')
    
                
    

	########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers, verify=False).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def resolve(name,url,iconimage,description):
    try: 
        stream_url=urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Home_Menu()
elif mode == 1 : Second_Menu(name,url)
elif mode == 2 : Soaps_Menu()
elif mode == 3 : Main_Menu(url)
elif mode == 4 : Shows_Menu(url)
elif mode == 5 : Search()
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
