# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin,xbmcaddon, xbmc, re, sys, os,cloudflare,net, base64
import urlresolver
import requests
from addon.common.addon import Addon
### With thanks to MetalKettle for the cloudflare bypass function
s = requests.session() 
net = net.Net()
addon_id = 'plugin.video.watchoverhere'
addon = Addon(addon_id, sys.argv)
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.watchoverhere/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'watchoverhere'
VERSION = '1.0.9'
BASEURL = 'http://www.directvfree.com/'
ART = ADDON_PATH + "resources/icons/"
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

def Main_menu():
    Menu('[B][COLOR blue]All TV Shows[/COLOR][/B]',BASEURL +'tvshows/',5,ART + 'alltv.jpg',FANART,'')
    Menu('[B][COLOR blue]Release Year[/COLOR][/B]',BASEURL,4,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR red]Search[/COLOR][/B]','url',6,ART + 'searchtv.jpg',FANART,'')
    OPEN = Open_Url('http://www.directvfree.com/')
    Regex = re.compile('<h3>DirecTV Categories(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)" >(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            name=name.replace('amp;','')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,5,ART + 'tvgen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_year(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>DirecTV Release year(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div id="mt-.+?".+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('-185x278','')
            name = name.replace('&#8217;','\'')
            Menu('[B][COLOR blue]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    np = re.compile("<link rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR white]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    

def Episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="numerando">.+?</div>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#039;','\'').replace('\n','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
   
def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="elemento">.+?<a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        name2 = url.split('//')[1].replace('www.','')
        name2 = name2.split('/')[0].split('.')[0].title()
        if 'Nosvideo' not in name2:
            if 'Vshare' not in name2:
                if 'Vidzi' not in name2:
                    if 'Flashx' not in name2:
                        if urlresolver.HostedMediaFile(url).valid_url():
                            Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)               
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                Get_content(url)
                
def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(cookie_file,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: 
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
	
def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR blue]WatchOverHere[/COLOR],[COLOR blue]Resolving Link[/COLOR] ,2000)")
    OPEN = Open_Url(url)
    play=urlresolver.resolve(url)
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(str(url),liz)
    
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 4: Get_year(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 8 : Episodes(url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
