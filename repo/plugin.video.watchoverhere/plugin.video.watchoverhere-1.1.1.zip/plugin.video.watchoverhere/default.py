# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, dandy, os,base64
import xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.watchoverhere'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'watchoverhere'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://kat.tv'
ART = ADDON_PATH + "/resources/icons/"
###alt url 'http://sockshare.net'

def Main_menu():
    addDir('[B][COLOR blue]Cinema Movies[/COLOR][/B]',BASEURL + '/cinema-movies.html',5,ART + 'cine_mov.jpg',FANART,'')
    addDir('[B][COLOR blue]New releases[/COLOR][/B]',BASEURL + '/search-movies/2017.html',5,ART + 'new_rel.jpg',FANART,'')
    addDir('[B][COLOR blue]Recently Added[/COLOR][/B]',BASEURL + '/new-movies.html',5,ART + 'rec_add.jpg',FANART,'')
    addDir('[B][COLOR blue]Cartoon Movie & Series[/COLOR][/B]',BASEURL + '/cartoon.html',5,ART + 'cart.jpg',FANART,'')
    addDir('[B][COLOR blue]Movies by Genres[/COLOR][/B]',BASEURL + '/genres.html',8,ART + 'm_genre.jpg',FANART,'')
    addDir('[B][COLOR blue]Movies by Year[/COLOR][/B]',BASEURL + '/years.html',8,ART + 'm_year.jpg',FANART,'')
    addDir('[B][COLOR blue]Movies by Country[/COLOR][/B]',BASEURL + '/countries.html',8,ART + 'm_count.jpg',FANART,'')
    addDir('[B][COLOR blue]TV Series[/COLOR][/B]',BASEURL + '/tv-series.html',5,ART + 'tv_ser.jpg',FANART,'')
    addDir('[B][COLOR blue]Anime Series[/COLOR][/B]',BASEURL + '/anime-series.html',5,ART + 'anime.jpg',FANART,'')
    addDir('[B][COLOR red]Search[/COLOR][/B]','url',7,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def page_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="thumb">.+?href="(.+?)".+?<b>(.+?)</b>.+?<img src="(.+?)".+?class="status status-year">(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,title,icon,year in Regex:
        name = title + ' (' + year +')'
        addDir('[B][COLOR blue]%s[/COLOR][/B]' %name,url,10,icon,FANART,name)
    np = re.compile('class="pagecurrent".+?href=(.+?).html',re.DOTALL).findall(OPEN)
    for url in np:
        url=url+'.html'
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def cats(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="thumbcontent">(.+?)</center>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR blue]%s[/COLOR][/B]' %name,url,5,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')


def host_links(name,url):
    OPEN = Open_Url(url)
    if '<a class="episode episode_series_link' in str(OPEN):
        Regex = re.compile('<a class="episode episode_series_link.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
        for url,name in Regex:
            addDir('[B][COLOR blue]Episode %s[/COLOR][/B]' %name,url,11,iconimage,FANART,'')
    else:
        Regex = re.compile('div class="server_line.+?href="(.+?)".+?class="server_servername">(.+?)</p>',re.DOTALL).findall(OPEN)
        for url,name2 in Regex:
            name2 = name2.replace('Server ','')
            if 'Veoh' in name2:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'OpenLoad' in name2:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'TheVideo' in name2:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'VidTo' in name2:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            
def series_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('div class="server_line.+?href="(.+?)".+?class="server_servername">(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        name2 = name2.replace('Server ','')
        if 'Veoh' in name2:
            addDir('[B][COLOR blue]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
        if 'OpenLoad' in name2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
        if 'TheVideo' in name2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
        if 'VidTo' in name2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            
def search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/search-movies/' + search + '.html'
                page_content(url)
########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers, verify=False).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def resolve(name,url):
        try:
            OPEN = Open_Url(url)
            link = re.compile('Base64.decode.+?"(.+?)"').findall(OPEN)[0]
            page = base64.b64decode(link)
            url = re.compile('src="(.+?)"',re.DOTALL).findall(page)[0]
            stream_url = urlresolver.resolve(url)
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(stream_url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2: 
        params=sys.argv[2] 
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
    return param

params      = get_params()
url         = None
name        = None
iconimage   = None
mode        = None
fanart      = None
description = None

try:    url=urllib.unquote_plus(params["url"])
except: pass
try:    name=urllib.unquote_plus(params["name"])
except: pass
try:    iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try:    mode=int(params["mode"])
except: pass
try:    fanart=urllib.unquote_plus(params["fanart"])
except: pass
try:    description=urllib.unquote_plus(params["description"])
except: pass

print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################

if mode == None: Main_menu()
elif mode == 5 : page_content(url)
elif mode == 7 : search()
elif mode == 8 : cats(url)
elif mode == 10 : host_links(name,url)
elif mode == 11 : series_links(name,url)
elif mode == 100 : resolve(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))