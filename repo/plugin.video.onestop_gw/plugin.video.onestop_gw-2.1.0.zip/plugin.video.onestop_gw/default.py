# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys
import requests
import xbmcaddon
from addon.common.addon import Addon
import urlresolver
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.onestop_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'onestop_gw'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL    = 'https://movieonline.io'
ART        = ADDON_PATH + "/resources/icons/"

def Main_menu():
    addDir('[B][COLOR white]Most Watched[/COLOR][/B]',BASEURL + '/populars.html?page=1',5,ART + 'mosts.jpg',FANART,'')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL + '/explore/movies.html?page=1',5,ART + 'all_mov.jpg',FANART,'')
    addDir('[B][COLOR white]Genre[/COLOR][/B]',BASEURL,3,ART + 'genre.jpg',FANART,'')
    addDir('[B][COLOR white]Release Year[/COLOR][/B]',BASEURL,4,ART + 'release.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows[/COLOR][/B]',BASEURL + '/explore/series.html?page=1',9,ART + 'tv_show.jpg',FANART,'')
    addDir('[B][COLOR white]Search All[/COLOR][/B]','url',6,ART + 'search_all.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu w1">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url = url.replace('utm_source=ws&utm_medium=menu&utm_campaign=genres','page=1')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu w3">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)" title="(.+?)">',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.replace('\\','')
        url = url.replace('utm_source=ws&utm_medium=menu&utm_campaign=release','page=1')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):    
    OPEN = Open_Url(url)
    page=url
    Regex = re.compile('<figure>.+?<a href="(.+?)".+?<img src="(.+?)".+?title="(.+?)".+?</span>.+?<span>(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,icon,title,qual in Regex:
        if 'Moana' not in title:
            icon = 'https:' + icon
            name = title + ' [COLOR red](' + qual + ')[/COLOR]'
            if '-season-' in url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,10,icon,FANART,'')    
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,100,icon,FANART,'')   
    curpage=int(page.split('=')[-1])
    nextp=str(curpage+1)
    page=page.replace(str(curpage),nextp)
    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',page,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(url):
    OPEN = Open_Url(url)
    link = re.compile('<div id="movie-player">.+?<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in link:
        addDir('[B][COLOR white]Google[/COLOR][/B]',url,101,iconimage,FANART,name)
    
    ol_link = re.compile('data-tab="openload" data-video="(.+?)"',re.DOTALL).findall(OPEN)
    for url in ol_link:
        addDir('[B][COLOR white]Openload[/COLOR][/B]','https://openload.co/f/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = open_url(url).content
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8217;','').replace('#038;','')
            icon = icon.replace('w90','w300_and_h450_bestv2')
            if '-season-' in url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')    
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  
      
def Get_TV(url):
    OPEN = Open_Url(url)
    page=url
    Regex = re.compile('<figure>.+?<a href="(.+?)".+?<img src="(.+?)".+?title="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        icon = 'https:' + icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,10,icon,FANART,'')    
    curpage=int(page.split('=')[-1])
    nextp=str(curpage+1)
    page=page.replace(str(curpage),nextp)
    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',page,5,ART + 'next_page.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="fa fa-server">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.replace(' Episode','Episode').replace('\\','').replace(' Eepisode','Episode').replace(':Episode','Episode').replace(' Epiosde','Episode').replace(' Epicode','Episode')   
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
########################################

def Search(query=None):
        if query and query != None and query != "":
                search = query.replace(' ','+')
        else:
                keyb = xbmc.Keyboard('', 'Search')
                keyb.doModal()
                if (keyb.isConfirmed()):
                        search = keyb.getText().replace(' ','+')
        url = BASEURL + '/movie/search.html?keyword=' + search
        search_res(url)

def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<figure>.+?<a href="(.+?)".+?<img src="(.+?)".+?title="(.+?)".+?class="fa fa-plus"></i></span>.+?<span>(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,icon,name,qual in Regex:
            if 'season' in url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,10,icon,FANART,'') 
            else:
                name = name + ' [COLOR red](' + qual + ')[/COLOR]'
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL + url,100,icon,FANART,'')    
    xbmc.executebuiltin('Container.SetViewMode(50)')

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
    
def RESOLVE(name,url,iconimage,description):
    res_quality = []
    stream_url = []
    quality = ''
    OPEN = Open_Url(url)
    link = re.compile('<div id="movie-player">.+?<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
    End = Open_Url(link)
    match = re.compile("src='(.+?)'.+?label='(.+?)'",re.DOTALL).findall(End)
    for link, label in match:
        if 'auto' not in label:
            quality = '[B][COLOR white]%s[/COLOR][/B]' %label
            res_quality.append(quality)
            stream_url.append(link)
    if len(match) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Quality',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                    url = stream_url[ret]
    else:
        url = re.compile("src='(.+?)'",re.DOTALL).findall(End)[0]
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)        

def resolve(name,url,iconimage,description):
    stream_url=urlresolver.resolve(url) 
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None
query=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        query=urllib.unquote_plus(params["query"])
except:
        pass
# OpenELEQ: ^^ Added query as param to be pulled

print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################

if mode == None: Main_menu()
elif mode == 3 : Get_Genres(url)
elif mode == 4 : Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search(query)
elif mode == 7 : search_res(url)
elif mode == 9 : Get_TV(url)
elif mode == 10 : Get_episodes(url)
elif mode == 100 : RESOLVE(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
