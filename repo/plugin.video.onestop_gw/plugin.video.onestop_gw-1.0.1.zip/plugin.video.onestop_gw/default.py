# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, base64
import xbmcaddon,xbmcvfs
from addon.common.addon import Addon
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.onestop_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'onestop_gw'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://www.freemoviesu.to/'
ART = ADDON_PATH + "/resources/icons/"


def Main_menu():
    addDir('[B][COLOR white]Feature Movies[/COLOR][/B]',BASEURL,4,ART + 'feat.jpg',FANART,'')
    addDir('[B][COLOR white]Bluray Movies[/COLOR][/B]',BASEURL+'category/bluray/',5,ART + 'blu.jpg',FANART,'')
    addDir('[B][COLOR white]1080P Movies[/COLOR][/B]',BASEURL+'category/1080p/',5,ART + '1080.jpg',FANART,'')
    addDir('[B][COLOR white]720P Movies[/COLOR][/B]',BASEURL+'category/720p/',5,ART + '720.jpg',FANART,'')
    addDir('[B][COLOR white]WEB-DL[/COLOR][/B]',BASEURL+'category/web-dl/',5,ART + 'web.jpg',FANART,'')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL,5,ART + 'all_mov.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR white]Search[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>Genres</h3>(.+?)id="sidebar-follow">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("http://www.freemoviesu.to/tag/(.+?)/",re.DOTALL).findall(str(Regex))
    for url in Regex2:
        name = url.title()
        if 'Zac-Blair' not in name:
            if 'Brett-Sullivan' not in name:
                if 'Travis-Betz' not in name:
                    addDir('[B][COLOR white]%s[/COLOR][/B]' %name,'http://www.freemoviesu.to/tag/%s'%url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_feature(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>Feature Movies</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" title="(.+?)">.+?src="(.+?)"/>',re.DOTALL).findall(str(Regex))
    for url,name,icon in Regex2:
        icon = icon.split('-')[1]
        icon = 'http://www.freemoviesu.to/wp-'+icon+'.jpg'
        name = name.replace('\\\'','\'').replace('&#8211;','-').replace('#038;','').replace('&#039;','\'').replace('&#8217;','\'')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="thumbnail">.+?<a href="(.+?)".+?title="(.+?)">.+?src="(.+?)"/>',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            icon = icon.replace('-185x278','')
            name = name.replace('&#8211;','-').replace('#038;','').replace('&#039;','\'').replace('&#8217;','\'')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("class='current'.+?<a href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
                    addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_links(name,url):
    OPEN = Open_Url(url)    
    Mainlinks = re.compile('Links:(.+?)</p>',re.DOTALL).findall(OPEN)
    Mainlinks2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Mainlinks))
    for url,name2 in Mainlinks2:    ######## Raptu final host https resolvable if was not/ playernaut added but maybe deb
                if 'Thevideo' in name2 or 'Openload' in name2 or 'Rapidvideo' in name2 or 'Playernaut' in name2: ########## nb userfiles.com if working
                    addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
                if 'HD Host 1' in name2:
                    addDir('[B][COLOR white]GoogleLink[/COLOR][/B]',url,101,iconimage,FANART,name)
                if 'HD HOST 3' in name2:
                    try:
                        Link = Open_Url(url)
                        page = re.compile('<iframe id=.+?src="(.+?)"',re.DOTALL).findall(Link)[0]
                        page = 'http:' + page
                        End = Open_Url(page)
                        url = re.compile('var ff = "(.+?)"',re.DOTALL).findall(End)[0]
                        url = url.replace('vidembed-','')
                        addDir('[B][COLOR white]Usercloud[/COLOR][/B] [COLOR red](Debrid)[/COLOR]',url,100,iconimage,FANART,name)
                    except:pass
    catch_old = re.compile('Movie Player.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in catch_old:
        if 'nosvideo' not in url:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)   
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + 'search/' + search
                Get_content(url)
    
	
########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==101:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(name,url):
    if 'watch.freemoviesu' in url:
        try:
            Link = Open_Url(url)
            page = re.compile('<iframe id=.+?src="(.+?)"',re.DOTALL).findall(Link)[0]
            page = 'http:' + page
            End = Open_Url(page)
            url = re.compile('var base64code="(.+?)"',re.DOTALL).findall(End)[0]
            url = base64.b64decode(url)
            url = urlresolver.resolve(url)
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)   
        except:pass   
            
    else:
        try:
            url = urlresolver.resolve(url)
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except:pass


def resolve_gog(name,url):
    Link = Open_Url(url)
    page = re.compile('<iframe id=.+?src="(.+?)"',re.DOTALL).findall(Link)[0]
    page = 'http:' + page
    End = Open_Url(page)
    try:              
        url = re.compile('"label".+?"src":"(.+?)"',re.DOTALL).findall(End)[1]
    except:
        url = re.compile('"label".+?"src":"(.+?)"',re.DOTALL).findall(End)[0]
        
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)  
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_feature(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url)
elif mode == 101 : resolve_gog(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
