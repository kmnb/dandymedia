# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.movieecho'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'movieecho'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://www.movieecho.com'


def Main_menu():
    addDir('[B][COLOR white]Movies - Date Added[/COLOR][/B]',BASEURL+'/?sort=featured',5,ART + 'mda.jpg',FANART,'')
    addDir('[B][COLOR white]Movies - Popular[/COLOR][/B]',BASEURL+'/?sort=views',5,ART + 'mpop.jpg',FANART,'')
    addDir('[B][COLOR white]Movies - Rated[/COLOR][/B]',BASEURL+'/?sort=ratings',5,ART + 'mrate.jpg',FANART,'')
    addDir('[B][COLOR white]Movies - Favourites[/COLOR][/B]',BASEURL+'/?sort=favorites',5,ART + 'mfav.jpg',FANART,'')
    addDir('[B][COLOR white]Movies - Release Date[/COLOR][/B]',BASEURL+'/?sort=release',5,ART + 'mrel.jpg',FANART,'')
    addDir('[B][COLOR white]Movie -  Genres[/COLOR][/B]','',3,ART + 'mgen.jpg',FANART,'')
    addDir('[B][COLOR red]Search Movies[/COLOR][/B]','url',6,ART + 'msearch.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows - Date Added[/COLOR][/B]',BASEURL+'/?tv=&sort=date',7,ART + 'tvdate.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows - Popular[/COLOR][/B]',BASEURL+'/?tv=&sort=views',7,ART + 'tvpop.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows - Rated[/COLOR][/B]',BASEURL+'/?tv=&sort=ratings',7,ART + 'tvrated.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows - Favorites[/COLOR][/B]',BASEURL+'/?tv=&sort=favorites',7,ART + 'tvfav.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows - Release Date[/COLOR][/B]',BASEURL+'/?tv=&sort=release',7,ART + 'tvrel.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows -  Genres[/COLOR][/B]',BASEURL +'/?tv',12,ART + 'tvgenre.jpg',FANART,'')
    addDir('[B][COLOR red]Search TV Shows[/COLOR][/B]','url',11,ART + 'tvsearch.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Get_Genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('data-toggle="dropdown">Genre<span(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'mgen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TVGenres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-toggle="dropdown">Genre<span(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,7,ART + 'tvgenre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="item">.+?<a href="(.+?)" title="(.+?)">.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        icon = 'http:' + icon
        name = name.replace('Watch ','').replace('Online Free','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,10,icon,FANART,'')
    np = re.compile('<nav class="pagination">(.+?)<div style="clear: both">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a class="(.+?)".+?href="(.+?)">',re.DOTALL).findall(str(np))
    for name,url in np2:
            if 'current first num' in name:
                    addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]',BASEURL+url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_shows(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="item">.+?<a href="(.+?)".+?src="(.+?)".+?<h2 class="movie-title">(.+?)</h2>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = 'http:' + icon
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,8,icon,FANART,'')
    np = re.compile('<nav class="pagination">(.+?)<div style="clear: both">',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a class="(.+?)".+?href="(.+?)">',re.DOTALL).findall(str(np))
    for name,url in np2:
            if 'current first num' in name:
                    addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]',BASEURL+url,7,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_seasons(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('class="season-toggle" href="(.+?)">(.+?)<span',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#9658; ','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,9,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_episodes(url):
    referer = url
    headers = {'Host': 'www.movieecho.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="tv_episode_item"> <a href="(.+?)">(.+?)<span class="tv_episode_name">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,namex,namey in Regex:
            name = namex+namey
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_links(name,url,iconimage):
    OPEN = Open_Url(url)
    Regex = re.compile('_version_link.+?href="(.+?)"+?version_host">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
            if 'Sponsor Host' not in name2:
                    if 'Promo Host' not in name2:
                            if 'vodlock' not in name2:
                                    if 'nosvideo.com' not in name2:
                                            if 'thevideobee.to' not in name2:
                                                        if 'vidzi.tv' not in name2:
                                                            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,BASEURL+url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?search_keywords=' + search
                Get_content(url)
    
def SearchTV():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?tv=&search_keywords=' + search
                Get_shows(url)
	
########################################


def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100 or mode==101:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def resolve(name,url,iconimage,description):
    try:
        headers = {'User-Agent': User_Agent}
        r = requests.get(url,headers=headers,allow_redirects=False)
        url = r.headers['location'] 
        stream_url=urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR cornflowerblue]Link Unavailable[/COLOR] ,5000)") 		


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres()
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_shows(url)
elif mode == 8 : Get_seasons(url)
elif mode == 9 : Get_episodes(url)
elif mode == 10 : Get_links(name,url,iconimage)
elif mode == 11 : SearchTV()
elif mode == 12 : Get_TVGenres(url)
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
