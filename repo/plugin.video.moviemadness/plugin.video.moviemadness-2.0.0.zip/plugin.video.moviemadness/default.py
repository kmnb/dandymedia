# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, dandy, xbmcplugin, xbmc, re, sys
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.moviemadness/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'moviemadness'
VERSION = '2.0.0'
BASEURL = 'http://movietube.top/'
ART = ADDON_PATH + "resources/icons/"

def Main_menu():
    Menu('[B][COLOR white]Hot Movies[/COLOR][/B]',BASEURL+'list/hot/',5,ART + 'hot.jpg',FANART,'')
    Menu('[B][COLOR white]Latest Movies[/COLOR][/B]',BASEURL+'list/cinema/',5,ART + 'latest.jpg',FANART,'')
    Menu('[B][COLOR white]Best Rated Movies[/COLOR][/B]',BASEURL,7,ART + 'rated.jpg',FANART,'')
    Menu('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,3,ART + 'mov_gen.jpg',FANART,'')
    Menu('[B][COLOR white]Release Year[/COLOR][/B]',BASEURL,4,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR white]Search[/COLOR][/B]','url',6,ART + 'search_mov.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>Genres(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)" >(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'mov_gen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>Release year(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):    
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'movietube.top', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<div id="mt-.+?href="(.+?)">.+?src=".+?url=(.+?).jpg.+?alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon +'.jpg'
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8217;','\'').replace('&#8211;','').replace('#038;','')
            Page = Open_Url(url)
            try:
                url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(Page)[0]
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
            except:pass
    np = re.compile('<link rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_rated(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div id="slider2"(.+?)</div></div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="imagens">.+?href="(.+?)">.+?src=".+?url=(.+?).jpg.+?alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
            icon = icon +'.jpg'
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8217;','\'').replace('&#8211;','').replace('#038;','')
            Page = Open_Url(url)
            try:
                url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(Page)[0]
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
            except:pass
    xbmc.executebuiltin('Container.SetViewMode(50)')    

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="pestana.+?data-src="(.+?)">',re.DOTALL).findall(OPEN)
    for url in Regex:
        name2 = url.split('//')[1].replace('www.','')
        name2 = name2.split('/')[0].split('.')[0].title()
        name2 = name2.replace('Hnmovies','Googlelink').replace('Hnzoom','Googlelink')
        if '404.php' not in url:
            if 'gogocartoon.to' not in url: 
                Play('[B][COLOR white]%s[/COLOR][/B]'%name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL + '?s=' + search
            Get_content(url)				

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
 


 

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR red]WooHoo[/COLOR],[COLOR cornflowerblue]Resolving Link[/COLOR] ,2000)")
    if 'hnmovies.com' in url:
            OPEN = Open_Url(url)
            url = re.compile('file: "(.*?)"').findall(OPEN)[0]
            play=urlresolver.resolve(url)
    if 'http://hnzoom.com' in url:
            OPEN = Open_Url(url)
            try:
                    url = re.compile('"file":"(.*?)"').findall(OPEN)[0]
            except:
                    url = re.compile('"file":"(.*?)"').findall(OPEN)[1]
    if 'hnzoom.com' in url:
            url= 'http:'+url
            OPEN = Open_Url(url)
            url = re.compile('<source src="(.*?)"').findall(OPEN)[0]
            play=urlresolver.resolve(url)
    if 'entervideo.net' in url:
            OPEN = Open_Url(url)
            url = re.compile('<source src="(.+?)"').findall(OPEN)[0]
    if 'vidstream.io' in url:
            url=url.replace('http://vidstream.io/','http://vidstreaming.io/')
            OPEN = Open_Url(url)
            url = re.compile("<source src='(.*?)'").findall(OPEN)[0]
            play=urlresolver.resolve(url)

    else:   
            play=urlresolver.resolve(url)     
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(url,liz)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_rated(url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
