# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy, xbmcaddon
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.toptvshows'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'toptvshows'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://cooltvseries.com/'


def Main_menu():
    addDir('[B][COLOR white]Popular Shows[/COLOR][/B]',BASEURL +'popular-tv-shows/',1,ART + 'popular.jpg',FANART,'')
    addDir('[B][COLOR white]Latest Episodes[/COLOR][/B]',BASEURL +'moreupdates/',4,ART + 'latestep.jpg',FANART,'')
    addDir('[B][COLOR white]Alphabetically[/COLOR][/B]','',2,ART + 'alpha.jpg',FANART,'')
    addDir('[B][COLOR red]Search[/COLOR][/B]','url',25,ART + 'search.jpg',FANART,'')
    OPEN = Open_Url('http://cooltvseries.com/popular-tv-shows/')
    Regex = re.compile('<h3 class="sidebar-title">Browse By Category</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            if 'Documentary' not in name:
                if 'Music' not in name:
                    if 'Sport' not in name:
                        if 'War' not in name:
                            if 'Western' not in name:
                                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,ART + 'genres.jpg',FANART,'')
    setView('tvshows', 'default-view')


def alpha():
    OPEN = Open_Url('http://cooltvseries.com/popular-tv-shows/')
    Regex = re.compile('<h3 class="sidebar-title">Browse By Alphabetically</h3>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,ART + 'alpha.jpg',FANART,'')
    setView('tvshows', 'default-view')

def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,icon,FANART,'')
    np = re.compile('<li class="next"><a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
            url = url.replace('https','http')
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,1,ART + 'next_page.jpg',FANART,'')
    setView('tvshows', 'tvshows-view')
    
def latest_ep(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    setView('tvshows', 'default-view')

def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="dwn-box">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    setView('tvshows', 'default-view')
	
def Get_episodes(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="dwn-box">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)<span',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            url = url.replace('https','http')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    setView('tvshows', 'default-view')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + 'search.php?search=' + search
                search_res(url)

def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="box">.+?<img src="(.+?)".+?<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
            url = url.replace('https','http')
            icon = icon.replace('//','http://')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    setView('tvshows', 'default-view')                

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def resolve(name,url,iconimage,description):
    OPEN = Open_Url(url)
    try:
        url = re.compile('href="https://cooltvseries.com/dl/(.+?)"',re.DOTALL).findall(OPEN)[-1]
        url = 'http://cooltvseries.com/dl/' + url
        headers = {'User-Agent': User_Agent}
        r = requests.get(url,headers=headers,allow_redirects=False)
        url = r.headers['location']
        url = url.replace(' ','%20')        
    except:
        url = re.compile('href="https://cooltvseries.com/dl/(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = 'http://cooltvseries.com/dl/' + url
        headers = {'User-Agent': User_Agent}
        r = requests.get(url,headers=headers,allow_redirects=False)
        url = r.headers['location']
        url = url.replace(' ','%20')
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 1 : Get_content(url)
elif mode == 2 : alpha()
elif mode == 4 : latest_ep(url)
elif mode == 5 : Get_seasons(url)
elif mode == 10 : Get_episodes(url)
elif mode == 25 : Search()
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
