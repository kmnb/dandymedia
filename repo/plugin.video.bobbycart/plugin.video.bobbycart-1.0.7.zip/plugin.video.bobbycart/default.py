# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon, dandy
from addon.common.addon import Addon
import urlresolver
addon_id='plugin.video.bobbycart'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'bobbycart'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"


def Main_Menu():
    OPEN = Open_Url('https://raw.githubusercontent.com/dandy0850/iStream/master/test/maintoons.txt')
    Regex = re.compile('<title>(.+?)</title>.+?url>(.+?)</url>.+?thumb>(.+?)</thumb>.+?art>(.+?)</art>',re.DOTALL).findall(OPEN)
    for name,url,icon,fanart in Regex:
            if 'http://www.kisspanda.net/' in url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,fanart)
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,fanart) 
    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]','https://raw.githubusercontent.com/dandy0850/iStream/master/test/toons.txt',3,ART + 'nextpage.jpg',FANART,'')	
    setView('tvshows', 'tvshows-view')

def second_page(url):
    OPEN = Open_Url('https://raw.githubusercontent.com/dandy0850/iStream/master/test/toons.txt')
    Regex = re.compile('<title>(.+?)</title>.+?url>(.+?)</url>.+?thumb>(.+?)</thumb>.+?art>(.+?)</art>',re.DOTALL).findall(OPEN)
    for name,url,icon,fanart in Regex:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,fanart)
    setView('tvshows', 'tvshows-view')

	
def kiss_get(url,description):
    fanart = description
    OPEN = Open_Url(url)
    Regex = re.compile('<a title="(.+?)" href="(.+?)">',re.DOTALL).findall(OPEN)
    for name,url in Regex:
            name = name.replace('&#8217;','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,fanart,'')
    setView('tvshows', 'default-view')
    
def toon_get(url,description):
    fanart = description
    OPEN = Open_Url(url)
    Regex = re.compile('&nbsp;&nbsp;<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
            name = name.replace('&#8217;','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,fanart,'')
    np = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
            if 'Next' in name:
                    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,2,iconimage,fanart,'')
    setView('tvshows', 'default-view')

	########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(name,url,iconimage,description):
    if 'toonget' in url:
        OPEN = Open_Url(url)
        Link = re.compile('<iframe src="http://videozoo.me/(.+?)"',re.DOTALL).findall(OPEN)
        for get_url in Link:
            get_url = 'http://videozoo.me/'+ get_url
            final = Open_Url(get_url)
            stream_url = re.compile("playlist:.+?url: '(.+?)'",re.DOTALL).findall(final)[1]  ####keep eye on changed from 0
    elif 'kisspanda.net' in url:
        OPEN = Open_Url(url) 
        url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        stream_url = urlresolver.resolve(url)
    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)



def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_Menu()
elif mode == 1 : kiss_get(url,description)
elif mode == 2 : toon_get(url,description)
elif mode == 3 : second_page(url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
