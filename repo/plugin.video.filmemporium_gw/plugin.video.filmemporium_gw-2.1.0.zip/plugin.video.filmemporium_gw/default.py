# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os,dandy, xbmcaddon,cloudflare,net
from addon.common.addon import Addon
import requests
import urlresolver
s = requests.session() 
net = net.Net()
addon_id='plugin.video.filmemporium_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
BASEURL = 'https://thewatchseries.us'
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

def Main_menu():
    addDir('[B][COLOR deepskyblue]Newest Added/Updated content[/COLOR][/B]',BASEURL + '/new-release?page=1',5,ART + 'latest.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]Movies[/COLOR][/B]',BASEURL + '/movies?page=1',5,ART + 'allmov.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]Cinema Movies[/COLOR][/B]',BASEURL + '/cinema-movies?page=1',5,ART + 'cinema.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]UK Only - Shows and Movies[/COLOR][/B]',BASEURL + '/list?key=&country=12&year=&genre=&quality=all&type=all&sort=&Filter=Filter&page=1',7,ART + 'ukonly.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]UK Only - Alphabetically[/COLOR][/B]',BASEURL + '/list',11,ART + 'alphauk.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]US Only - Shows and Movies[/COLOR][/B]',BASEURL + '/list?key=&country=13&year=&page=1',7,ART + 'usonly.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]US Only - Alphabetically[/COLOR][/B]',BASEURL + '/list',12,ART + 'alphaUS.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]Shows and Movies [All][/COLOR][/B]',BASEURL + '/list',7,ART + 'allcount.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]Shows and Movies [All Alpha][/COLOR][/B]',BASEURL + '/list',8,ART + 'alphaall.jpg',FANART,'')
    addDir('[B][COLOR deepskyblue]Full Search[/COLOR][/B]','url',20,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Get_content(url):    
    OPEN = Open_Url(url)
    page=url
    referer = url
    headers = {'Host': 'thewatchseries.ru', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<li rel="tooltip".+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            if '-season-' in url:
                name = name.lstrip()
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,9,icon,FANART,name)    
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,100,icon,FANART,name)
    curpage=int(page.split('=')[-1])
    nextp=str(curpage+1)
    page=page.replace(str(curpage),nextp)
    page=page.replace('www3','www2')
    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',page,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_episodes(url,name,iconimage):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="bottom">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" title="(.+?)"',re.DOTALL).findall(str(Regex))
    Regex2 = list(reversed(Regex2))
    for url,name in Regex2:
        name=name.replace('\\','')
        name = name.replace(description,'').replace(': Episode','Episode').replace(':  Episode','Episode').replace('; Episode','Episode').lstrip()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,'https://thewatchseries.us%s'%url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_cinema(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'thewatchseries.ru', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<span>CINEMA MOVIES</span>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li rel="tooltip".+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
        name=name.replace('\\','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_alpha(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'thewatchseries.ru', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<div class="apha">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" rel="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR deepskyblue]%s[/COLOR][/B]' %name,BASEURL+url,7,ART + 'alphaall.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def full_list(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'thewatchseries.ru', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<div class="list_movies">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)".+?>(.+?)</a>.+?<span>(.+?)</span>',re.DOTALL).findall(str(Regex))
    for url,title,year in Regex2:
        name = title + ' [COLOR red](' + year + ')[/COLOR]'
        name=name.replace('\\','')
        geticon = BASEURL + url
        try:
            get_icon = Open_Url(geticon)
            icon = re.compile('<meta itemprop="image" content="(.+?)"').findall(get_icon)[0]
        except:
            icon=ICON
        if '-season-' in url:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %title,BASEURL+url,9,icon,FANART,title)    
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,100,icon,FANART,'')
    np = re.compile("<li class='next'><a href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        url = '/list' + url
        addDir('[B][COLOR red]Next Page >>>>[/COLOR][/B]',BASEURL+url,7,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def alpha_uk(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'thewatchseries.us', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<div class="apha">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" rel="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url = url + '&country=12&year=&sort=&Filter=Filter'
        addDir('[B][COLOR deepskyblue]%s[/COLOR][/B]' %name,BASEURL+url,7,ART + 'alphauk.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def alpha_US(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'thewatchseries.us', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<div class="apha">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" rel="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url = url + '&country=13&year=&sort=&Filter=Filter'
        addDir('[B][COLOR deepskyblue]%s[/COLOR][/B]' %name,BASEURL+url,7,ART + 'alphaUS.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','%20')
            url = BASEURL + '/search.html?keyword=' + search
            search_res(url)

def search_res(url):
    OPEN = Open_Url(url)
    referer = url
    headers = {'Host': 'www2.thewatchseries.us', 'User-Agent': User_Agent, 'Referer': referer}
    Regex = re.compile('<ul class="listing items">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" />',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
            if '-season-' in url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,9,icon,FANART,name)    
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  
########################################try above

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok    

def resolve(name,url,iconimage,description):
    if '/info/' in url:
        NP = Open_Url(url)
        url = re.compile('Latest Episode:.+?<a href="(.+?)"',re.DOTALL).findall(NP)[0]
        url = BASEURL + url
        OPEN = Open_Url(url)
        holderpage = re.compile('<iframe src="(.+?)"').findall(OPEN)[0]
        link = Open_Url(holderpage)
        url = re.compile("<source src='(.+?)'",re.DOTALL).findall(link)[-1]
    else:
        OPEN = Open_Url(url)
        holderpage = re.compile('<iframe src="(.+?)"').findall(OPEN)[0]
        link = Open_Url(holderpage)
        try:
            url = re.compile("<source src='(.+?)'",re.DOTALL).findall(link)[-1]
        except:
            link = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(link)[0]
            url=urlresolver.HostedMediaFile(link).resolve()
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 6: Get_cinema(url)
elif mode == 7 : full_list(url)
elif mode == 8 : Get_alpha(url)
elif mode == 9: Get_episodes(url,name,iconimage)
elif mode == 11 : alpha_uk(url)
elif mode == 12 : alpha_US(url)
#elif mode == 10 : Get_links(name,url) could open all links 
elif mode == 15 : search_res(url)
elif mode == 20 : Search()
elif mode == 100 : resolve(name,url,iconimage,description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
