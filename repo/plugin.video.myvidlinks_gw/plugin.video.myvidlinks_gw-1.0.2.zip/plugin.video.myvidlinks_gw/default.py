# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import xbmcaddon,xbmcvfs
from addon.common.addon import Addon
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.myvidlinks_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'myvidlinks_gw'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://newmyvideolink.xyz/sites/'
ART = ADDON_PATH + "/resources/icons/"


def Main_menu():
    addDir('[B][COLOR gold]Latest Posts[/COLOR][/B]',BASEURL,5,ART + 'latest.jpg',FANART,'')
    addDir('[B][COLOR gold]2017 Movies[/COLOR][/B]',BASEURL+'category/allmovies/2017/',5,ART + '2017.jpg',FANART,'')
    addDir('[B][COLOR gold]2016 Movies[/COLOR][/B]',BASEURL+'category/allmovies/2016/',5,ART + '2016.jpg',FANART,'')
    addDir('[B][COLOR gold]2015 Movies[/COLOR][/B]',BASEURL + 'category/allmovies/2015/',5,ART + '2015.jpg',FANART,'')
    addDir('[B][COLOR gold]Older Movies[/COLOR][/B]',BASEURL + 'category/allmovies/older/',5,ART + 'older.jpg',FANART,'')
    addDir('[B][COLOR gold]All  Movies[/COLOR][/B]',BASEURL+'category/allmovies/',5,ART + 'all_mov.jpg',FANART,'')
    addDir('[B][COLOR gold]3D - Movies[/COLOR][/B]',BASEURL + 'category/allmovies/3dmovies/',5,ART + '3d.jpg',FANART,'')
    addDir('[B][COLOR gold]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR gold]TV Shows[/COLOR][/B]',BASEURL + 'category/tv-shows/',5,ART + 'tvshows.jpg',FANART,'')
    addDir('[B][COLOR gold]Search[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="tagcloud">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("http://newmyvideolink.xyz/sites/tag/(.+?)/",re.DOTALL).findall(str(Regex))
    for url in Regex2:
        name = url.title()
        addDir('[B][COLOR gold]%s[/COLOR][/B]' %name,'http://newmyvideolink.xyz/sites/tag/%s'%url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="post_content">.+?href="(.+?)".+?<img src="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8211;','-').replace('#038;','').replace('&#039;','\'').replace('&#8217;','\'')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<ul class='page-numbers'>(.+?)</ul>",re.DOTALL).findall(OPEN)
    np2 = re.compile('<a class="next page-numbers" href="(.+?)"',re.DOTALL).findall(str(np))
    for url in np2:
        addDir('[B][COLOR gold]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_links(url):
    OPEN = Open_Url(url)
    Mainlinks = re.compile('<div class="post_content">.+?<ul>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Mainlinks2 = re.compile('href="(.+?)"',re.DOTALL).findall(str(Mainlinks))
    for url in Mainlinks2:
        name2 = url.split('//')[1].replace('www.','')
        name2 = name2.split('/')[0].split('.')[0].title()
        if urlresolver.HostedMediaFile(url).valid_url():
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)   
    altlinks = re.compile('<div class="post_content">.+?</ul>(.+?)</ul>',re.DOTALL).findall(OPEN)
    try:
        altlinks2 = re.compile('href="(.+?)"',re.DOTALL).findall(str(altlinks))
        for url in altlinks2:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            if urlresolver.HostedMediaFile(url).valid_url():
                if '/embed/' not in url:
                    addDir('[B][COLOR white]%s [COLOR red](720p)[/COLOR][/B]' %name2,url,100,iconimage,FANART,name) 
    except:pass
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '?s=' + search
                Get_content(url)
    
	
########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(url):
    try:
        url = urlresolver.resolve(url)
    except:pass
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(url)
elif mode == 100 : resolve(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
