# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys,xbmcaddon,os,dandy
import urlresolver
from addon.common.addon import Addon 
addon_id='plugin.video.tvtimes'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'tvtimes'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://tv-release.pw'


def Main_menu():
    addDir('[B][COLOR white]Movies XviD[/COLOR][/B]',BASEURL + '/cat/Movies-XviD',5,ICON,FANART,'')
    addDir('[B][COLOR white]Movies 720[/COLOR][/B]',BASEURL + '/cat/Movies-720p',5,ICON,FANART,'')
    addDir('[B][COLOR white]Movies 480[/COLOR][/B]',BASEURL + '/cat/Movies-480p',5,ICON,FANART,'')
    addDir('[B][COLOR blue]TV 720[/COLOR][/B]',BASEURL + '/cat/TV-720p',5,ICON,FANART,'')
    addDir('[B][COLOR blue]TV 480[/COLOR][/B]',BASEURL + '/cat/TV-480p',5,ICON,FANART,'')
    addDir('[B][COLOR blue]TV Mp4[/COLOR][/B]',BASEURL + '/cat/TV-Mp4',5,ICON,FANART,'')
    addDir('[B][COLOR blue]TV XviD[/COLOR][/B]',BASEURL + '/cat/TV-XviD',5,ICON,FANART,'')
    addDir('[B][COLOR red]Search[/COLOR][/B]','url',6,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<td class='w64'.+?<a href='(.+?)'>(.+?)</a>.+?class='w18 coll-date'>(.+?) .+?</td>",re.DOTALL).findall(OPEN)
    for url,name,date in Regex:
                name = name.replace(' 480p HDTV x264','').replace(' 480p x264-mSD','').replace(' 720p HDTV x264','').replace('-W4F','').replace('-DHD','').replace(' 720p WEB','').replace(' 480p WEBRip x264','').replace(' 480p WEB-DL x264','')
                name2= name+' '+'[B][COLOR blue]%s[/COLOR]'%date
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,10,ICON,FANART,'')
    np = re.compile('<span class=\'(.+?)\'>.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for name,url in np:
            if 'zmg_pn_current' in name:
                    addDir('[B][COLOR blue]Next Page >>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

		
	
def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile("href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in Regex:
        name2 = url.split('//')[1].replace('www.','')
        name2 = name2.split('/')[0].split('.')[0].title()
        if urlresolver.HostedMediaFile(url).valid_url():
            if '.rar' not in url:
                if 'Filefactory' in name2:
                    name2=name2.replace('Filefactory','[B][COLOR red]FileFactory[/COLOR][/B]')
                    addDir(name2,url,100,ART + 'filefactory.jpg',FANART,name)
                if 'Rapidgator' in name2:
                    name2=name2.replace('Rapidgator','[B][COLOR orange]Rapidgator[/COLOR][/B]')
                    addDir(name2,url,100,ART + 'rapid.jpg',FANART,name)
                if 'Ul' in name2:
                    name2=name2.replace('Ul','[B][COLOR blue]Uploaded[/COLOR][/B]')
                    addDir(name2,url,100,ART + 'uploaded.jpg',FANART,name)
                if 'Uploading' in name2:
                    name2=name2.replace('Uploading','[B][COLOR white]UploadingSite[/COLOR][/B]')
                    addDir(name2,url,100,ART + 'upsite.jpg',FANART,name)
        if 'Multiup' in name2:
            url=url.replace('https://www.multiup.org/en/mirror/','http://www.multiup.org/en/mirror/').replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
            OPEN = Open_Url(url)
            Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
            for name2, validity, url in Regex:
                name2 = name2.title()
                if 'invalid' not in validity:
                    if urlresolver.HostedMediaFile(url):
                        addDir('[B][COLOR white]%s (Multiup)[/COLOR][/B]' %name2,url,100,ART + 'm_up.jpg',FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','%20')
                url = BASEURL + '/?s=' + search + '&cat='
                Get_content(url)
    

########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(name,url,iconimage,description):
    iconimage=ICON
    try:    
        stream=urlresolver.HostedMediaFile(url).resolve()
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
