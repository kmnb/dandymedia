# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, dandy,xbmcaddon
import requests
from addon.common.addon import Addon

s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.filmcube'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'filmcube'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'https://flenix.net'


def Main_menu():
    addDir('[B][COLOR white]Trending Movies[/COLOR][/B]',BASEURL+'/movies/trending/',5,ART + 'trend_mov.jpg',FANART,'')
    addDir('[B][COLOR white]New Releases[/COLOR][/B]',BASEURL+'/movies/releases/',5,ART + 'mov_new.jpg',FANART,'')
    addDir('[B][COLOR white]Movies in HD[/COLOR][/B]',BASEURL+'/movies/hd/',5,ART + 'mov_hd.jpg',FANART,'')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL+'/movies/',5,ART + 'allmov.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR white]Release Year[/COLOR][/B]',BASEURL,4,ART + 'rel_year.jpg',FANART,'')
    addDir('[B][COLOR white]Trending TV[/COLOR][/B]',BASEURL+'/tv/trending/',5,ART + 'ttv.jpg',FANART,'')
    addDir('[B][COLOR white]New Releases TV[/COLOR][/B]',BASEURL+'/tv/releases/',5,ART + 'mov_new.jpg',FANART,'')
    addDir('[B][COLOR white]All TV Shows[/COLOR][/B]',BASEURL+'/tv/',5,ART + 'all_tv.jpg',FANART,'')
    addDir('[B][COLOR white]Search All[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

    
def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<span>Movies</span>.+?<ul class="reset">(.+?)<span>TV Shows</span>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<span>Movies</span>.+?<div>Sort by year:</div>(.+?)</li>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'rel_year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):    
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="poster item-flip">.+?src="(.+?)".+?<div class="title">(.+?)</div>.+?<span>(.+?)</span>.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,title,year,url in Regex:
            name = title + ' [COLOR red](' + year + ')[/COLOR]'
            if '/tv/' in  url:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile('<span>[0-9]</span> <a href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'next.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    referer = url
    headers = {'Host': 'flenix.net', 'User-Agent': User_Agent, 'Referer': referer}
    links=requests.get(url,headers=headers,allow_redirects=True).content
    Regex = re.compile('file:"(.+?)"',re.DOTALL).findall(links)
    for url in Regex:
        url = 'https:' + url
        name=url
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,ART + 'rel_year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_show_content(name,url):
    referer = url
    epis_numb=0
    headers = {'Host': 'flenix.net', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    holderpage = re.compile('<iframe id="movie" class="tcontainer" src="(.+?)"').findall(OPEN)[0]
    links=requests.get(holderpage,headers=headers,allow_redirects=True).content
    Regex = re.compile('/video/t/(.+?)"',re.DOTALL).findall(links)
    for url in Regex:
        epis_numb = epis_numb +1
        name2 = epis_numb
        addDir('[B][COLOR white]Episode %s - [/COLOR][/B]' %name2 + name,'https://hdgo.cx/video/t/%s'%url,101,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/index.php?do=search&story=' + search
                Get_content(url)
    

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100 or mode==101:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def resolve(url):
    referer = url
    headers = {'Host': 'flenix.net', 'User-Agent': User_Agent, 'Referer': referer}
    try:
        links=requests.get(url,headers=headers,allow_redirects=True).content
        stream_url = re.compile('file:"(.+?)"',re.DOTALL).findall(links)[0]
        stream_url = 'https:' + stream_url
    except:
        OPEN = Open_Url(url)
        holderpage = re.compile('<iframe id="movie" class="tcontainer" src="(.+?)"').findall(OPEN)[0]
        links=requests.get(holderpage,headers=headers,allow_redirects=True).content
        stream_url = re.compile("url: '(.+?)'",re.DOTALL).findall(links)[-1]
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

# def resolve(url):
    # liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    # liz.setInfo(type="Video", infoLabels={"Title": description})
    # liz.setProperty("IsPlayable","true")
    # liz.setPath(url)
    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)


def resolve_tv(url):
    referer = url
    headers = {'Host': 'flenix.net', 'User-Agent': User_Agent, 'Referer': referer}
    links=requests.get(url,headers=headers,allow_redirects=True).content
    stream_url = re.compile("url: '(.+?)'",re.DOTALL).findall(links)[-1]
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    xbmc.executebuiltin('Container.SetViewMode(50)')


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 9 : Get_show_content(name,url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(url)
elif mode == 101 : resolve_tv(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
