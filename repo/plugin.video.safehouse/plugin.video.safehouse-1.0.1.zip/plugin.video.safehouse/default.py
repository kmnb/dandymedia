# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
import xbmcaddon,xbmcvfs
from addon.common.addon import Addon
import urlresolver
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.safehouse'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'safehouse'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://www.vmovee.click/'
ART = ADDON_PATH + "/resources/icons/"


def Main_menu():
    addDir('[B][COLOR white]Popular Movies[/COLOR][/B]',BASEURL + 'sort/hot/',5,ART + 'popular.jpg',FANART,'')
    addDir('[B][COLOR white]Featured[/COLOR][/B]',BASEURL,4,ART + 'featured.jpg',FANART,'')
    addDir('[B][COLOR white]Recently Added[/COLOR][/B]',BASEURL + 'index.php?gold=&sub_gold=&q=&page=1',5,ART + 'recent.jpg',FANART,'')
    addDir('[B][COLOR white]Top IMDB[/COLOR][/B]',BASEURL + 'sort/imdb/',5,ART + 'top.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR white]Search[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<hr class="sep-line">(.+?)</div></div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" class="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        url=url.replace('/genre/','/index.php?gold=genre&sub_gold=')
        if not 'TV Shows' in name:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="movie-element movie-element-size-1".+?<a href="(.+?)".+?/gold-app/gold-uploads/media/(.+?).jpg.+?<div class=".+?_box_title">(.+?)</div>.+?<div class=".+?_box_info">(.+?)<div style="float:right.+?>(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,icon,name,year,type in Regex:
        if 'HDTV' not in type:
            if 'AD' not in type:
                icon = 'http://www.vmovee.click/gold-app/gold-uploads/media/' + icon + '.jpg'
                name = name + ' (' + year + ') [COLOR red][' + type + '][/COLOR]'
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("class='ng-scope'.+?class='ng-scope'><a href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'next.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_feat(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="movie-element-top movie-element-size-1".+?<a href="(.+?)".+?background-image: url\((.+?)\);".+?<div style="float:left.+?>(.+?)</div>.+?<div style="float:right.+?>(.+?)</div>.+?<div class="trend_box_title" >(.+?)</div>',re.DOTALL).findall(OPEN)
    for url,icon,year,type,name in Regex:
        if 'HDTV' not in type:
            name = name + ' (' + year + ') [COLOR red][' + type + '][/COLOR]'
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_links(name,url):
    OPEN = Open_Url(url)    
    links = re.compile('#myBtn.+?"src", "(.+?)"',re.DOTALL).findall(OPEN)
    for url in links:
        if urlresolver.HostedMediaFile(url).valid_url():
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
        elif 'http:'not in url:
            try:
                url = 'http:' + url
                headers = {'User-Agent': User_Agent}
                r = requests.get(url,headers=headers,allow_redirects=False)
                url = r.headers['location']
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()            
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            except:pass
        else:
            headers = {'User-Agent': User_Agent}
            r = requests.get(url,headers=headers,allow_redirects=False)
            url = r.headers['location']
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()            
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + 'search?x=0&y=0&q=' + search
                Get_content(url)
    
	
########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(name,url):
        url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4 : Get_feat(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
