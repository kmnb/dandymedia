# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin,dandy, xbmc, re, sys, os
import xbmcaddon,xbmcvfs
# A special thanks, My addons contain some code originally written by MuckyDuck,
# His permission for use, help and guidance I will always be grateful.
from addon.common.addon import Addon
User_Agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13F69'
addon_id='plugin.video.safehouse'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'safehouse'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://hdmovie.today/'
ART = ADDON_PATH + "/resources/icons/"


def Main_menu():
    addDir('[B][COLOR white]Most Veiwed[/COLOR][/B]',BASEURL + 'category/high-rate/?bycat=25&byorder=viewed',5,ART + 'viewed.jpg',FANART,'')
    addDir('[B][COLOR white]Recommended Movies[/COLOR][/B]',BASEURL + 'category/high-rate/',5,ART + 'recom.jpg',FANART,'')
    addDir('[B][COLOR white]Latest Update[/COLOR][/B]',BASEURL + 'category/high-rate/?bycat=25&byorder=year',5,ART + 'latest.jpg',FANART,'')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL + 'list/movie/',5,ART + 'allmov.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]','',3,ART + 'gens.jpg',FANART,'')
    addDir('[B][COLOR white]Release Year[/COLOR][/B]','',4,ART + 'release.jpg',FANART,'')
    addDir('[B][COLOR red]TV Shows[/COLOR][/B]',BASEURL + 'list/drama/',7,ART + 'tvshow.jpg',FANART,'')
    addDir('[B][COLOR red]Search Movies[/COLOR][/B]','url',6,ART + 'search_mov.jpg',FANART,'')     
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<img class="thumbimg lazy".+?data-original="(.+?)".+?href="(.+?)" title="(.+?)".+?</a>(.+?)</p>',re.DOTALL).findall(OPEN)
    for icon,url,title,info in Regex:
        title = title.replace(' - EngSub','').replace('Engsub','').replace(' - NoSub','').replace(' - ','').replace('&#8217;','\'').replace('&#8211;','-').replace('&#39','\'').replace('&amp;','&')
        info = info.lstrip().replace('(','').replace(')',')[/COLOR]')
        name = title + ' [COLOR red](' + info + ''
        if 'Season ' not in name:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile("<a title='Next'.+?href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>>[/COLOR][/B]',url,5,ART + 'next.jpg',FANART,'')

def Get_tv(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<img class="thumbimg lazy".+?data-original="(.+?)".+?href="(.+?)" title="(.+?)".+?</a>(.+?)</p>',re.DOTALL).findall(OPEN)
    for icon,url,title,info in Regex:
        title = title.replace(' - EngSub','').replace('Engsub','').replace(' - NoSub','').replace('&#8217;','\'').replace('&#8211;','-').replace('&#39','\'').replace('&amp;#38','&')
        info = info.lstrip()
        name = title +' '+ info
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,8,icon,FANART,'')
    np = re.compile("<a title='Next'.+?href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>>[/COLOR][/B]',url,5,ART + 'next.jpg',FANART,'')

def Get_Genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>Category<(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.title()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'gens.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_years():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>List Year<(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.replace('Film ','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'release.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_epis(url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="episode_.+?href="(.+?)">(.+?)</a>').findall(OPEN)
    for url,name in Regex:
            addDir('[B][COLOR white]Episode %s[/COLOR][/B]' %name,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def TV_links(url):
    OPEN = Open_Url(url)
    Regex = re.compile('"file":"(.+?)".+?"label":"(.+?)"',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
            addDir('[B][COLOR white]Play in %s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_links(url):
    OPEN = Open_Url(url)
    holderpage = re.compile('<div class="fiml-img".+?href="(.+?)"').findall(OPEN)[0]
    links = Open_Url(holderpage)
    Regex = re.compile('"file":"(.+?)".+?"label":"(.+?)"',re.DOTALL).findall(links)
    for url,name2 in Regex:
            addDir('[B][COLOR white]Play in %s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','-')
                url = BASEURL + 'search/' + search
                Get_content(url)

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def resolve(name,url):
    OPEN = Open_Url(url)
    try:
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(OPEN)[0]
    except:
        holderpage = re.compile('<div class="fiml-img".+?href="(.+?)"').findall(OPEN)[0]
        links = Open_Url(holderpage)
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(links)[0]
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':name})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
      
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres()
elif mode == 4: Get_years()
elif mode == 5 : Get_content(url)
elif mode == 7 : Get_tv(url)
elif mode == 8 : Get_epis(url)
elif mode == 6 : Search()
elif mode == 9: TV_links(url)
elif mode == 10: Get_links(url)
elif mode == 100 : resolve(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
