# -*- coding: utf-8 -*-
import os,re,requests,sys,urllib, dandy
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
from addon.common.addon import Addon

addon_id='plugin.video.t4charts'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
s = requests.session()

def CAT():
        addDir('[B][COLOR white]UK Singles Top 40[/COLOR][/B]','http://top40-charts.com/chart.php?cid=25',1,ART + 'uk.jpg',FANART,'')
        addDir('[B][COLOR white]USA Singles Top 40[/COLOR][/B]','http://top40-charts.com/chart.php?cid=27',1,ART + 'us.jpg',FANART,'')
        addDir('[B][COLOR white]Canada Singles Top 40[/COLOR][/B]','http://top40-charts.com/chart.php?cid=9',1,ART + 'can.jpg',FANART,'')
        addDir('[B][COLOR white]Airplay World Official Top 100[/COLOR][/B]','http://top40-charts.com/chart.php?cid=31',1,ART + 'world100.jpg',FANART,'')
        addDir('[B][COLOR white]Europe Official Top 100[/COLOR][/B]','http://top40-charts.com/chart.php?cid=31',1,ART + 'europe100.jpg',FANART,'')
        addDir('[B][COLOR white]Digital Sales Top 100[/COLOR][/B]','http://top40-charts.com/chart.php?cid=5',1,ART + 'digital100.jpg',FANART,'')
        addDir('[B][COLOR white]Top40-Charts Web Top 100[/COLOR][/B]','http://top40-charts.com/chart.php?cid=39',1,ART + 'top40web.jpg',FANART,'')
        addDir('[B][COLOR white]World Singles Top 100[/COLOR][/B]','http://top40-charts.com/chart.php?cid=35',1,ART + 'worldsing100.jpg',FANART,'')
        addDir('[B][COLOR white]World Soundtracks[/COLOR][/B]','http://top40-charts.com/chart.php?cid=44',1,ART + 'wsound.jpg',FANART,'')
        addDir('[B][COLOR white]World Country Top 20[/COLOR][/B]','http://top40-charts.com/chart.php?cid=30',1,ART + 'country20.jpg',FANART,'')
        addDir('[B][COLOR white]World Dance / Trance Top 30[/COLOR][/B]','http://top40-charts.com/chart.php?cid=40',1,ART + 'dance.jpg',FANART,'')
        addDir('[B][COLOR white]Modern Rock Top 30[/COLOR][/B]','http://top40-charts.com/chart.php?cid=41',1,ART + 'modrock.jpg',FANART,'')
        addDir('[B][COLOR white]World RnB Top 30[/COLOR][/B]','http://top40-charts.com/chart.php?cid=33',1,ART + 'wrnb.jpg',FANART,'')
        xbmc.executebuiltin('Container.SetViewMode(50)')	
		
		
		
def Main_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile("img.youtube.com/vi/(.+?)/.+?Artist:(.+?)'",re.DOTALL).findall(OPEN)
    for url,name in Regex:
            img = 'https://i.ytimg.com/vi/'+url+'/hqdefault.jpg'
            addDir(name,'plugin://plugin.video.youtube/play/?video_id=%s'%url,100,img,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')		
		

	########################################

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def Open_Url(url):
	headers = {}
	headers['User-Agent'] = User_Agent
	link = s.get(url, headers=headers, allow_redirects=False).text
	link = link.encode('ascii', 'ignore')
	return link
		

def resolve(name,url,iconimage,description):
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: CAT()
elif mode == 1 : Main_Menu(url)

elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
