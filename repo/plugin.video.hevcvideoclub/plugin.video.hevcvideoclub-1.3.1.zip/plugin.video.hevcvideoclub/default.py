# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy, xbmcaddon,cloudflare,net
import urlresolver
import requests
net = net.Net()
from addon.common.addon import Addon
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.hevcvideoclub'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'hevcvideoclub'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://300mbmoviesdl.co/'
BASEURL2 = 'http://300mbmovies4u.co/'

try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

def Main_menu():
    addDir('[B][COLOR white]Recently Added[/COLOR][/B]',BASEURL,5,ART + 'recent.jpg',FANART,'')
    addDir('[B][COLOR white]720p Movies[/COLOR][/B]',BASEURL + 'category/english-720p-bluray-movies/',5,ART + '720p.jpg',FANART,'')
    addDir('[B][COLOR white]1080p Movies[/COLOR][/B]',BASEURL + 'category/english-1080p-bluray-movies/',5,ART + '1080p.jpg',FANART,'')
    addDir('[B][COLOR white]720p WEB-DL[/COLOR][/B]',BASEURL + 'category/english-720p-web-dl/',5,ART + '720p.jpg',FANART,'')
    addDir('[B][COLOR white]1080p WEB-DL[/COLOR][/B]',BASEURL + 'category/english-1080p-web-dl/',5,ART + '1080p.jpg',FANART,'')
    addDir('[B][COLOR white]3D Movies[/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/english-3d-movie/',7,ART + '3Dmov.jpg',FANART,'')
    addDir('[B][COLOR white]Latest TV Episodes[/COLOR][/B]',BASEURL2 + 'category/tv-shows/',7,ICON,FANART,'')
    addDir('[B][COLOR white]IMDB[/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/imdb-top-250-movie/',7,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR white]More HEVC[/COLOR][/B]',BASEURL2 + 'category/hevc-movie/',7,ICON,FANART,'')
    addDir('[B][COLOR white]300mb Movies[/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/300mb-movie/',7,ICON,FANART,'')
    addDir('[B][COLOR white]More 720p[/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/720p-movie/',7,ART + '720p.jpg',FANART,'')
    addDir('[B][COLOR white]More 1080p [/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/english-1080p-movie/',7,ART + '1080p.jpg',FANART,'')
    addDir('[B][COLOR white]BluRay[/COLOR][/B]',BASEURL2 + 'category/hollywood-movie/bluray-movie-hollywood-movie/',7,ICON,FANART,'')
    addDir('[B][COLOR red]Search Movies[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

	
def Get_content(url):
    referer = url
    headers = {'Host': 'www.300mbmoviesdl.com', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="cover">.+?<a href="(.+?)" title="(.+?)"><img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
            name = name.replace('HEVC','-').replace('&#8217;','').replace('720p',' - [COLOR blue](720p)[/COLOR]').replace('1080p',' - [COLOR blue](1080p)[/COLOR]')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<link rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_m4u(url):
    referer = url
    headers = {'Host': '300mbmovies4u.net', 'User-Agent': User_Agent, 'Referer': referer}
    OPEN = Open_Url(url)
    Regex = re.compile('id="content">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('="post-thumb">.+?href="(.+?)" title="(.+?)".+?src="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name,icon in Regex2:
            name = name.replace('HEVC','-').replace('&#8211;','').replace('&#8217;','').replace('720p',' - [COLOR blue](720p)[/COLOR]').replace('1080p',' - [COLOR blue](1080p)[/COLOR]')
            name = name.replace('\xe2\x80\x99','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,7,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    
	
def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('Watch in Online</h1>(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(Regex))
    for url in Regex2:
            if 'amazon.com' in url:
                addDir('[B][COLOR white]Direct Link[/COLOR][/B]',url,100,iconimage,FANART,name)
            if urlresolver.HostedMediaFile(url):
                    name2 = url.split('//')[1].replace('www.','')
                    name2 = name2.split('/')[0].capitalize()
                    name2 = name2.replace('Uploadx.org','Uploadx.org [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.link','Clicknupload.link [COLOR red](Krypton or Debrid Req)[/COLOR]').replace('Userscloud.com','Userscloud.com [COLOR red](Debrid Req)[/COLOR]').replace('Downace.com','Downace.com [COLOR red](Krypton Only)[/COLOR]')
                    if 'Filecloud.io' not in name2:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'multiup.org' in url:
                    url=url.replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/').replace('http://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
                    OPEN = Open_Url(url)
                    Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
                    for name2, validity, url in Regex:
                        if 'invalid' not in validity:
                            if urlresolver.HostedMediaFile(url):
                                if 'filecloud.io' not in name2:
                                    addDir('[B][COLOR white]%s [COLOR blue] (Multiup)[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    alt = re.compile('>Download.+?Link</h1>(.+?)New Download Links',re.DOTALL).findall(OPEN)
    alt2 = re.compile('href="(.+?)"',re.DOTALL).findall(str(alt))
    for url in alt2:
            if urlresolver.HostedMediaFile(url):
                    name2 = url.split('//')[1].replace('www.','')
                    name2 = name2.split('/')[0].capitalize()
                    name2 = name2.replace('Uploadx.org','Uploadx.org [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.link','Clicknupload.link [COLOR red](Krypton or Debrid Req)[/COLOR]').replace('Userscloud.com','Userscloud.com [COLOR red](Debrid Req)[/COLOR]').replace('Clicknupload.me','Clicknupload.link [COLOR red](Krypton or Debrid Req)[/COLOR]')
                    addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
            if 'multiup.org' in url:
                    url=url.replace('https://www.multiup.org/download/','http://www.multiup.org/en/mirror/').replace('http://www.multiup.org/download/','http://www.multiup.org/en/mirror/')
                    OPEN = Open_Url(url)
                    Regex = re.compile('nameHost="(.+?)".+?validity=(.+?)dateLastChecked=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
                    for name2, validity, url in Regex:
                        if 'invalid' not in validity:
                            if urlresolver.HostedMediaFile(url):
                                if 'filecloud.io' not in name2:
                                    name2 = name2.capitalize()
                                    addDir('[B][COLOR white]%s [COLOR blue] (Multiup)[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)            
    xbmc.executebuiltin('Container.SetViewMode(50)')


def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '?s=' + search
                Get_content(url)
    

########################################

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


def resolve(name,url,iconimage,description):
    url=urlresolver.HostedMediaFile(url).resolve()
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def OPEN_UrlRez():
        xbmcaddon.Addon('script.module.urlresolver').openSettings()

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 7 : Get_m4u(url)
elif mode == 6 : Search()
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)
elif mode == 200: OPEN_UrlRez()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
