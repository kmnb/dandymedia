# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import xbmcaddon,xbmcvfs
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.inthemovies'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'inthemovies'
VERSION = ADDON.getAddonInfo('version')
BASEURL = 'http://www.streamingtime.net/'
ART = ADDON_PATH + "/resources/icons/"


def Main_menu():
    addDir('[B][COLOR white]Newest Movies[/COLOR][/B]',BASEURL,5,ART + 'newest.jpg',FANART,'')
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('<div class="dropdown-content">(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile("<a class='link' href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,'http://www.streamingtime.net/%s'%url,5,ART + 'genre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="col-frontpage center">.+?<a href="(.+?)" class="center movieview" style="background-image:url\(\'(.+?)\'\);">.+?<p class="center movietitle">(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,'http://www.streamingtime.net/%s'%url,100,'http://www.streamingtime.net/%s'%icon,FANART,'')
    npage = re.compile('<div class="pagination">(.+?)</div>',re.DOTALL).findall(OPEN)
    np2 = re.compile("<a href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(npage))
    for url,name in np2:
        if '>' in name:
            if '>>' not in name:
                addDir('[B][COLOR blue]Next Page>>>[/COLOR][/B]','http://www.streamingtime.net/%s'%url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
		

def resolve(name,url):
    OPEN = Open_Url(url)
    url = re.compile('<source src="(.+?)"').findall(OPEN)[0]
    if 'https://redirector.getlinkdrive' in url:
        url = url.replace('https','http')
        headers = {'User-Agent': User_Agent}
        r = requests.get(url,headers=headers,allow_redirects=False)
        url = r.headers['location']
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    else: 
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 5 : Get_content(url)
elif mode == 100 : resolve(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
