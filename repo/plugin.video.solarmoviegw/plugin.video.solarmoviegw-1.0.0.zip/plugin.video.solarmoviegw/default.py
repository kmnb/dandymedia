# -*- coding: utf-8 -*-
import dandy, os, re, requests, sys, urllib2, urllib, urlresolver, xbmc, xbmcaddon, xbmcgui, xbmcplugin
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
from addon.common.addon import Addon
addon_id='plugin.video.solarmoviegw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'solarmoviegw'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL     = 'http://putlockerz.ws/'


def Main_menu():
    addDir('[B][COLOR white]Featured Movies[/COLOR][/B]', BASEURL + '/movies?sort=featured', 5, ART + 'featured.jpg', FANART, '')
    addDir('[B][COLOR white]Recently Added[/COLOR][/B]', BASEURL + '/movies?sort=recent', 5, ART + 'recent.jpg', FANART, '')
    addDir('[B][COLOR white]Most Popular[/COLOR][/B]', BASEURL + '/movies?sort=popular', 5, ART + 'pop.jpg', FANART, '')
    addDir('[B][COLOR white]Movies - By Genres[/COLOR][/B]', '', 3, ART + 'genre.jpg', FANART, '')
    addDir('[B][COLOR white]Movies - By Year[/COLOR][/B]', '', 4, ART + 'year.jpg', FANART, '')
    addDir('[B][COLOR white]Movies - A to Z[/COLOR][/B]', '', 2, ART + 'a_z.jpg', FANART, '')
    addDir('[B][COLOR orange]Search Movies[/COLOR][/B]', 'url', 6, ART + 'search.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<td width="18.6%".+?<a href="(.+?)" title="(.+?)">.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('Watch ','').replace('Online Free Full Movie','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<div class="pagination"><ul>(.+?)</ul>',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(np))
    for url,name in np2:
        if 'Last' not in name :
            if '&raquo' in name:
                    addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL+url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    
    
def Get_a_to_z():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('A-Z List</a>(.+?)</td>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'DMCA' not in name:
            if 'Us/Report' not in name:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'a_z.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_year():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>Years</a>(.+?)A-Z List</a>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>Genres</a>(.+?)Years</a>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'genre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<td width="100%" class="entry">.+?a href=.+?<a href="(.+?)".+?>(.+?)<',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if urlresolver.HostedMediaFile(url):
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/search_movies?s=' + search
                Get_Content(url)


########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers = headers).text
    link = link.encode('ascii', 'ignore')
    return link

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def resolve(name, url, iconimage, description):
    stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2: 
        params = sys.argv[2] 
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'): params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2: param[splitparams[0]] = splitparams[1]
    return param



params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass


if   mode == None : Main_menu()
elif mode == 2    : Get_a_to_z()
elif mode == 3    : Get_Genres()
elif mode == 4    : Get_year()
elif mode == 5    : Get_Content(url)
elif mode == 6    : Search()
elif mode == 10   : Get_links(name, url)
elif mode == 100  : resolve(name, url, iconimage, description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))