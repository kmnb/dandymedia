# -*- coding: utf-8 -*-
import dandy, os, re, requests, sys, urllib2, urllib, urlresolver, xbmc, xbmcaddon, xbmcgui, xbmcplugin
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
SHID        = ID.replace('plugin.video.','')
ART         = ADDON_PATH + "/resources/icons/"
BASEURL     = 'http://putlockerz.ws/'


def Main_menu():
    Menu('[B][COLOR white]Featured Movies[/COLOR][/B]', BASEURL + '/movies?sort=featured', 5, ART + 'featured.jpg', FANART, '')
    Menu('[B][COLOR white]Recently Added[/COLOR][/B]', BASEURL + '/movies?sort=recent', 5, ART + 'recent.jpg', FANART, '')
    Menu('[B][COLOR white]Most Popular[/COLOR][/B]', BASEURL + '/movies?sort=popular', 5, ART + 'pop.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - By Genres[/COLOR][/B]', '', 3, ART + 'genre.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - By Year[/COLOR][/B]', '', 4, ART + 'year.jpg', FANART, '')
    Menu('[B][COLOR white]Movies - A to Z[/COLOR][/B]', '', 2, ART + 'a_z.jpg', FANART, '')
    Menu('[B][COLOR orange]Search Movies[/COLOR][/B]', 'url', 6, ART + 'search.jpg', FANART, '')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<td width="18.6%".+?<a href="(.+?)" title="(.+?)">.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('Watch ','').replace('Online Free Full Movie','')
        Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('<div class="pagination"><ul>(.+?)</ul>',re.DOTALL).findall(OPEN)
    np2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(np))
    for url,name in np2:
        if 'Last' not in name :
            if '&raquo' in name:
                    Menu('[B][COLOR red]Next Page>>>[/COLOR][/B]',BASEURL+url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')    
    
def Get_a_to_z():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('A-Z List</a>(.+?)</td>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'DMCA' not in name:
            if 'Us/Report' not in name:
                Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'a_z.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_year():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>Years</a>(.+?)A-Z List</a>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres():
    OPEN = Open_Url(BASEURL)
    Regex = re.compile('>Genres</a>(.+?)Years</a>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'genre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')



def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<td width="100%" class="entry">.+?a href=.+?<a href="(.+?)".+?>(.+?)<',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        if urlresolver.HostedMediaFile(url):
            Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search(query = None):
    if query and query != None and query != "": search = query.replace(' ','+')
    else:
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()): search = keyb.getText().replace(' ','+')
    url = BASEURL + '/search_movies?s=' + search
    Get_Content(url)


########################################

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers = headers).text
    link = link.encode('ascii', 'ignore')
    return link

def Menu(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
        liz.setInfo(type = "Video", infoLabels = {"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Play(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0]+"?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
        liz.setInfo(type = "Video", infoLabels = {"Title": name, "Plot": description})
        liz.setProperty( "Fanart_Image", fanart)
        ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetPlayerCore(): 
    try: 
        PlayerMethod = getSet("core-player") 
        if   (PlayerMethod == 'DVDPLAYER'): PlayerMeth = xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod == 'MPLAYER')  : PlayerMeth = xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod == 'PAPLAYER') : PlayerMeth = xbmc.PLAYER_CORE_PAPLAYER 
        else                              : PlayerMeth = xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth = xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def resolve(name, url, iconimage, description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR orange]Attempting To[/COLOR],[COLOR green]Resolve Link[/COLOR] ,3000)")
    play = urlresolver.resolve(url)
    try: 
        liz = xbmcgui.ListItem(name, iconImage = 'DefaultVideo.png', thumbnailImage = iconimage)
        liz.setInfo(type = 'Video', infoLabels = {'Title': name, 'Plot': description})
        liz.setProperty('IsPlayable','true')
        xbmc.Player().play(play, liz)
    except:
        play = xbmc.Player(GetPlayerCore())
        play.play(str(url), liz)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2: 
        params = sys.argv[2] 
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'): params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2: param[splitparams[0]] = splitparams[1]
    return param

description = DESCRIPTION
fanart      = FANART
iconimage   = ICON
mode        = None
name        = NAME
params      = get_params()
query       = None
url         = BASEURL


try   : url         = urllib.unquote_plus(params["url"])
except: pass
try   : name        = urllib.unquote_plus(params["name"])
except: pass
try   : iconimage   = urllib.unquote_plus(params["iconimage"])
except: pass
try   : mode        = int(params["mode"])
except: pass
try   : fanart      = urllib.unquote_plus(params["fanart"])
except: pass
try   : description = urllib.unquote_plus(params["description"])
except: pass
try   : query       = urllib.unquote_plus(params["query"])
except: pass


print str(SHID)     + ': ' + str(VERSION)
print "Mode: "      + str(mode)
print "URL: "       + str(url)
print "Name: "      + str(name)
print "IconImage: " + str(iconimage)
#########################################################

if   mode == None : Main_menu()
elif mode == 2    : Get_a_to_z()
elif mode == 3    : Get_Genres()
elif mode == 4    : Get_year()
elif mode == 5    : Get_Content(url)
elif mode == 6    : Search(query)
elif mode == 10   : Get_links(name, url)
elif mode == 100  : resolve(name, url, iconimage, description)
xbmcplugin.endOfDirectory(int(sys.argv[1]))