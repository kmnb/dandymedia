# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy,xbmcaddon,base64
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.dare_tv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'dare_tv'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://www.thedarewatch.com'


def Main_menu():
    addDir('[B][COLOR white]Latest Updated TV[/COLOR][/B]',BASEURL +'/new-shows',1,ART + 'late_tv.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows[/COLOR][/B]',BASEURL+'/tv-shows',2,ART + 'tv_shows.jpg',FANART,'')
    addDir('[B][COLOR white]TV by Genre[/COLOR][/B]',BASEURL,4,ART + 'tv_gen.jpg',FANART,'')
    addDir('[B][COLOR white]TV by Alpha[/COLOR][/B]',BASEURL,5,ART + 'tv_alpha.jpg',FANART,'')
    addDir('[B][COLOR white]Movies[/COLOR][/B]',BASEURL+'/movies',1,ART + 'movs.jpg',FANART,'')
    addDir('[B][COLOR white]Latest Movies[/COLOR][/B]',BASEURL +'/new-movies',1,ART + 'lat_mov.jpg',FANART,'')
    addDir('[B][COLOR white]Movies Most Watched[/COLOR][/B]',BASEURL+'/movies/favorites',1,ART + 'mov_wat.jpg',FANART,'')
    addDir('[B][COLOR white]Movie by Genre[/COLOR][/B]',BASEURL,3,ART + 'mov_gen.jpg',FANART,'')
    addDir('[B][COLOR white]Movie by IMDB[/COLOR][/B]',BASEURL+'/movies/imdb_rating',1,ART + 'imdb.jpg',FANART,'')
    addDir('[B][COLOR white]Search [/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    setView('tvshows', 'default-view')

def get_CONTENT(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="view_img".+?href="(.+?)".+?<img.+?src="(.+?)".+?title="(.+?)".+?class="left">(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,icon,title,epis in Regex:
        icon=icon.replace('213x317','259x385')
        if '/season/' in url:
            name = title + ' (' + epis + ')'
        else:
            name = title
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,name)
    np = re.compile('class=\'current.+?class=\'current.+?href=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR cyan]Next Page>>>[/COLOR][/B]',url,1,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="view_img".+?href="(.+?)".+?<img.+?src="(.+?)".+?title="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,name)
    np = re.compile('class=\'current.+?class=\'current.+?href=.+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR cyan]Next Page>>>[/COLOR][/B]',url,1,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def get_genre(url):
    OPEN = Open_Url(url)
    Regex = re.compile('/span>TV Shows<(.+?)</ul>',re.DOTALL).findall(OPEN)
    match = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in match:
        if 'All Shows' not in name:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,ART + 'tv_gen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def mov_genre(url):
    OPEN = Open_Url(url)
    Regex = re.compile('</span>Movies<(.+?)</ul>',re.DOTALL).findall(OPEN)
    match = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in match:
        if 'All Movies' not in name:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,ART + 'mov_gen.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def get_alpha(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="tagbar">(.+?)</ul>',re.DOTALL).findall(OPEN)
    match = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in match:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,ART + 'tv_alpha.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_seasons(url):
    OPEN = Open_Url(url)
    Regex = re.compile('All Seasons(.+?)</ul>',re.DOTALL).findall(OPEN)
    match = re.compile("href='(.+?)'>(.+?)</a>",re.DOTALL).findall(str(Regex))
    for url,name in match:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,11,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_epis(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h5 class="left">.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)') 


# def Get_LINKS(name,url):
    # OPEN = Open_Url(url)
    # Regex = re.compile("] = '(.+?)'",re.DOTALL).findall(OPEN)
    # for link in Regex:
        # host = base64.b64decode(link)
        # url=re.compile('.+?="(.+?)"',re.DOTALL).findall(host)[0]
        # name2 = url.split('//')[1].replace('www.','')
        # name2 = name2.split('/')[0].split('.')[0].title()
        # if urlresolver.HostedMediaFile(url).valid_url():
            # addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    # xbmc.executebuiltin('Container.SetViewMode(50)')
	

########################################    
def search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','%20')
                url = BASEURL + '/index.php?menu=search&query=' + search
                Search_res(url)

def Search_res(url):
    OPEN = Open_Url(url)
    TV = re.compile('TV show results for(.+?)</ul>',re.DOTALL).findall(OPEN)
    TV2 = re.compile('<div class="view_img".+?href="(.+?)".+?<img.+?src="(.+?)".+?title="(.+?)"',re.DOTALL).findall(str(TV))
    for url,icon,name in TV2:
        icon=icon.replace('amp;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    mov = re.compile('Movie results for(.+?)</ul>',re.DOTALL).findall(OPEN)
    mov2 = re.compile('<div class="view_img".+?href="(.+?)".+?<img.+?src="(.+?)".+?title="(.+?)"',re.DOTALL).findall(str(mov))
    for url,icon,name in mov2:
        icon=icon.replace('amp;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')          
########################################


def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def resolve(url):
    hosts = []
    stream_url = []
    host = ''
    try:
        OPEN = Open_Url(url)
        match = re.compile("] = '(.+?)'",re.DOTALL).findall(OPEN)
        for vid in match:
            host = base64.b64decode(vid)
            link=re.compile('.+?="(.+?)"',re.DOTALL).findall(host)[0]
            if urlresolver.HostedMediaFile(link).valid_url():
                label = link.split('//')[1].replace('www.','')
                label = label.split('/')[0].split('.')[0].title()
                label = label.replace('Docs','Google')
                host = '[B][COLOR white]%s[/COLOR][/B]' %label
                hosts.append(host)
                stream_url.append(link)
        if len(match) >1:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Please Select Host',hosts)
                if ret == -1:
                    return
                elif ret > -1:
                        url = stream_url[ret]
                        url=url.replace('/preview','/edit')
        else:
            vid = re.compile("] = '(.+?)'").findall(OPEN)[0]
            host = base64.b64decode(vid)
            url=re.compile('.+?="(.+?)"',re.DOTALL).findall(host)[0]
            url=url.replace('/preview','/edit')
            print '#################################' +url
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR cornflowerblue]No Links Available[/COLOR] ,5000)") 
    try:
        if 'gorillavid.in' in url:
            host=Open_Url(url)
            final_url=re.compile('file: "(.+?)"',re.DOTALL).findall(host)[0]
        else:    
            final_url=urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(final_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass
    

        
def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )

    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 1: get_CONTENT(url)
elif mode == 2: get_TV(url)
elif mode == 3: mov_genre(url)
elif mode == 4: get_genre(url)
elif mode == 5: get_alpha(url)
elif mode == 6: search()
elif mode == 10 : Get_seasons(url)
elif mode == 11 : Get_epis(url)
elif mode == 12 : Search()
#elif mode == 50 : Get_LINKS(name,url)
elif mode == 100 : resolve(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
